from PyQt6.QtWidgets import QMainWindow, QTabWidget, QApplication
from PyQt6.QtCore import QObject, pyqtSignal

from netgui.gui.theme import DARK_QSS, LIGHT_QSS
from netgui.gui.workers import PollWorker
from netgui.gui.tab_namespaces import NamespacesTab
from netgui.gui.tab_chain_wizard import ChainWizardTab
from netgui.gui.tab_bridges import BridgesTab
from netgui.gui.tab_proxy import ProxyTab
from netgui.gui.tab_profiles import ProfilesTab
from netgui.gui.tab_diagnostics import DiagnosticsTab
from netgui.gui.tab_settings import SettingsTab


class AppState(QObject):
    """Shared, cross-tab state: current live namespaces/tunnels/bridges and theme."""
    state_changed = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.state = {"namespaces": {}, "tunnels": {}, "bridges": {}, "proxies": {}}
        self.poller = PollWorker(interval_ms=3000)
        self.poller.tick.connect(self._on_tick)
        self.poller.start()

    def _on_tick(self, state):
        self.state = state
        self.state_changed.emit(state)

    def request_refresh(self):
        # Force an immediate state refresh instead of waiting up to 3s for
        # the next poll tick, so the UI (namespace/tunnel/bridge/proxy
        # tables) updates right after an action completes.
        self.poller.force_tick()

    def set_theme(self, name):
        app = QApplication.instance()
        if name == "dark":
            app.setStyleSheet(DARK_QSS)
        else:
            app.setStyleSheet(LIGHT_QSS)

    def shutdown(self):
        self.poller.stop()
        self.poller.wait(1000)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NetGUI - VPN Namespace & Chain Manager")
        self.resize(980, 720)

        self.app_state = AppState()

        tabs = QTabWidget()
        self.namespaces_tab = NamespacesTab(self.app_state)
        self.chain_tab = ChainWizardTab(self.app_state)
        self.bridges_tab = BridgesTab(self.app_state)
        self.proxy_tab = ProxyTab(self.app_state)
        self.profiles_tab = ProfilesTab(self.app_state)
        self.diagnostics_tab = DiagnosticsTab(self.app_state)
        self.settings_tab = SettingsTab(self.app_state)

        tabs.addTab(self.namespaces_tab, "Namespaces")
        tabs.addTab(self.chain_tab, "Chain Wizard")
        tabs.addTab(self.proxy_tab, "Proxy")
        tabs.addTab(self.bridges_tab, "Bridges")
        tabs.addTab(self.profiles_tab, "Profiles")
        tabs.addTab(self.diagnostics_tab, "Diagnostics && Logs")
        tabs.addTab(self.settings_tab, "Settings")

        self.setCentralWidget(tabs)

        self.app_state.state_changed.connect(self.namespaces_tab.refresh)
        self.app_state.state_changed.connect(self.bridges_tab.refresh)
        self.app_state.state_changed.connect(self.proxy_tab.refresh)
        self.app_state.state_changed.connect(self.diagnostics_tab.refresh)

    def closeEvent(self, event):
        self.app_state.shutdown()
        super().closeEvent(event)
