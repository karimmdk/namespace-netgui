from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QGroupBox,
    QFormLayout, QRadioButton, QButtonGroup, QTextEdit
)

from netgui.gui.workers import HelperWorker
from netgui.core.constants import REQUIRED_PKGS


class SettingsTab(QWidget):
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        theme_box = QGroupBox("Appearance")
        theme_layout = QHBoxLayout(theme_box)
        self.dark_radio = QRadioButton("Dark")
        self.light_radio = QRadioButton("Light")
        self.dark_radio.setChecked(True)
        group = QButtonGroup(self)
        group.addButton(self.dark_radio)
        group.addButton(self.light_radio)
        self.dark_radio.toggled.connect(lambda checked: checked and self.app_state.set_theme("dark"))
        self.light_radio.toggled.connect(lambda checked: checked and self.app_state.set_theme("light"))
        theme_layout.addWidget(self.dark_radio)
        theme_layout.addWidget(self.light_radio)
        layout.addWidget(theme_box)

        deps_box = QGroupBox("Dependencies (Arch / pacman)")
        deps_layout = QVBoxLayout(deps_box)
        check_btn = QPushButton("Check Dependencies")
        check_btn.clicked.connect(self.on_check)
        install_btn = QPushButton("Install Missing")
        install_btn.clicked.connect(self.on_install)
        row = QHBoxLayout()
        row.addWidget(check_btn)
        row.addWidget(install_btn)
        deps_layout.addLayout(row)
        self.deps_view = QTextEdit()
        self.deps_view.setReadOnly(True)
        deps_layout.addWidget(self.deps_view)
        layout.addWidget(deps_box)

        layout.addStretch()

    def on_check(self):
        worker = HelperWorker("check_deps", {})
        worker.finished_ok.connect(self._show_deps)
        worker.finished_err.connect(lambda err: self.deps_view.setPlainText(f"Error: {err}"))
        self._workers.append(worker)
        worker.start()

    def _show_deps(self, res):
        status = res.get("status", {})
        self._last_status = status
        lines = []
        for bin_, ok in status.items():
            lines.append(f"{'OK ' if ok else 'MISSING'}  {bin_}  (pkg: {REQUIRED_PKGS.get(bin_, bin_)})")
        self.deps_view.setPlainText("\n".join(lines))

    def on_install(self):
        missing = [b for b, ok in getattr(self, "_last_status", {}).items() if not ok]
        if not missing:
            self.deps_view.append("\nNothing to install (run Check first).")
            return
        worker = HelperWorker("install_deps", {"bins": missing})
        worker.finished_ok.connect(lambda res: self.deps_view.append("\nInstalled: %s" % res.get("installed")))
        worker.finished_err.connect(lambda err: self.deps_view.append(f"\nError: {err}"))
        self._workers.append(worker)
        worker.start()
