from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QLineEdit, QLabel, QComboBox, QGroupBox, QFormLayout,
    QMessageBox, QSpinBox, QHeaderView
)

from netgui.gui.workers import HelperWorker


class BridgesTab(QWidget):
    """Port Bridge Manager: socat host_port -> namespace:target_port."""
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        form_box = QGroupBox("Add Port Bridge")
        form = QFormLayout(form_box)
        self.ns_combo = QComboBox()
        self.target_port = QSpinBox()
        self.target_port.setRange(1, 65535)
        self.target_port.setValue(1080)
        self.host_port = QSpinBox()
        self.host_port.setRange(1, 65535)
        self.host_port.setValue(2080)

        form.addRow("Namespace:", self.ns_combo)
        form.addRow("Namespace port (proxy inside ns):", self.target_port)
        form.addRow("Host port (exposed on 127.0.0.1):", self.host_port)

        add_btn = QPushButton("Add Bridge")
        add_btn.clicked.connect(self.on_add)
        form.addRow(add_btn)
        layout.addWidget(form_box)

        table_box = QGroupBox("Active Bridges")
        tlayout = QVBoxLayout(table_box)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Namespace", "Host Port", "Target Port", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tlayout.addWidget(self.table)
        layout.addWidget(table_box)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

    def refresh(self, state: dict):
        namespaces = state.get("namespaces", {})
        current = self.ns_combo.currentText()
        self.ns_combo.clear()
        for name in namespaces:
            self.ns_combo.addItem(name)
        idx = self.ns_combo.findText(current)
        if idx >= 0:
            self.ns_combo.setCurrentIndex(idx)

        bridges = state.get("bridges", {})
        self.table.setRowCount(0)
        for bridge_id, meta in bridges.items():
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(meta.get("namespace", "")))
            self.table.setItem(row, 1, QTableWidgetItem(str(meta.get("host_port", ""))))
            self.table.setItem(row, 2, QTableWidgetItem(str(meta.get("target_port", ""))))
            remove_btn = QPushButton("Remove")
            remove_btn.clicked.connect(lambda _, bid=bridge_id: self.on_remove(bid))
            self.table.setCellWidget(row, 3, remove_btn)

    def on_add(self):
        ns = self.ns_combo.currentText()
        if not ns:
            QMessageBox.warning(self, "No namespace", "Create a namespace first.")
            return
        args = {"namespace": ns, "target_port": self.target_port.value(),
                "host_port": self.host_port.value()}
        worker = HelperWorker("add_bridge", args)
        worker.finished_ok.connect(lambda res: (self.status_label.setText("Bridge added."),
                                                  self.app_state.request_refresh()))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def on_remove(self, bridge_id):
        worker = HelperWorker("remove_bridge", {"bridge_id": bridge_id})
        worker.finished_ok.connect(lambda res: (self.status_label.setText("Bridge removed."),
                                                  self.app_state.request_refresh()))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def _on_error(self, err):
        self.status_label.setText(f"Error: {err}")
        QMessageBox.critical(self, "Error", err)
