from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QLineEdit, QLabel, QComboBox, QGroupBox, QFormLayout,
    QMessageBox, QHeaderView
)
from PyQt6.QtCore import Qt

from netgui.gui.workers import HelperWorker


class NamespacesTab(QWidget):
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        form_box = QGroupBox("Create Namespace")
        form = QFormLayout(form_box)
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. vpn-out")
        self.parent_combo = QComboBox()
        self.parent_combo.addItem("(none - attach to host)", None)
        self.host_ip_input = QLineEdit("10.200.200.1")
        self.ns_ip_input = QLineEdit("10.200.200.2")
        self.dns_input = QLineEdit("1.1.1.1,8.8.8.8")

        form.addRow("Name:", self.name_input)
        form.addRow("Parent namespace:", self.parent_combo)
        form.addRow("Local(parent) IP:", self.host_ip_input)
        form.addRow("This namespace IP:", self.ns_ip_input)
        form.addRow("DNS (comma separated):", self.dns_input)

        btn_row = QHBoxLayout()
        self.create_btn = QPushButton("Create Namespace")
        self.create_btn.clicked.connect(self.on_create)
        btn_row.addWidget(self.create_btn)
        form.addRow(btn_row)

        layout.addWidget(form_box)

        table_box = QGroupBox("Existing Namespaces")
        tbox_layout = QVBoxLayout(table_box)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Name", "Parent", "IP", "Public IP", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tbox_layout.addWidget(self.table)
        layout.addWidget(table_box)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

    def refresh(self, state: dict):
        namespaces = state.get("namespaces", {})
        self.parent_combo.clear()
        self.parent_combo.addItem("(none - attach to host)", None)
        for name in namespaces:
            self.parent_combo.addItem(name, name)

        self.table.setRowCount(0)
        for name, meta in namespaces.items():
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(name))
            self.table.setItem(row, 1, QTableWidgetItem(meta.get("parent") or "(host)"))
            self.table.setItem(row, 2, QTableWidgetItem(meta.get("ns_ip", "")))
            self.table.setItem(row, 3, QTableWidgetItem("-"))

            action_widget = QWidget()
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(0, 0, 0, 0)

            test_btn = QPushButton("Test IP")
            test_btn.clicked.connect(lambda _, n=name, r=row: self.on_test_ip(n, r))
            del_btn = QPushButton("Delete")
            del_btn.clicked.connect(lambda _, n=name: self.on_delete(n))

            action_layout.addWidget(test_btn)
            action_layout.addWidget(del_btn)
            self.table.setCellWidget(row, 4, action_widget)

    def on_create(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing name", "Please enter a namespace name.")
            return
        parent = self.parent_combo.currentData()
        dns = [d.strip() for d in self.dns_input.text().split(",") if d.strip()]
        args = {
            "name": name,
            "parent": parent,
            "host_ip": self.host_ip_input.text().strip(),
            "ns_ip": self.ns_ip_input.text().strip(),
            "dns": dns,
        }
        self.status_label.setText(f"Creating namespace {name}...")
        worker = HelperWorker("create_namespace", args)
        worker.finished_ok.connect(lambda res: self._on_create_ok(res))
        worker.finished_err.connect(lambda err: self._on_error(err))
        self._workers.append(worker)
        worker.start()

    def _on_create_ok(self, res):
        self.status_label.setText("Namespace '%s' created." % res.get("namespace"))
        self.app_state.request_refresh()

    def on_delete(self, name):
        confirm = QMessageBox.question(
            self, "Confirm delete",
            f"Delete namespace '{name}' and all its children/tunnels/bridges?")
        if confirm != QMessageBox.StandardButton.Yes:
            return
        worker = HelperWorker("delete_namespace", {"name": name})
        worker.finished_ok.connect(lambda res: (self.status_label.setText(f"Deleted {name}"), self.app_state.request_refresh()))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def on_test_ip(self, name, row):
        self.table.setItem(row, 3, QTableWidgetItem("testing..."))
        worker = HelperWorker("test_ip", {"namespace": name})
        worker.finished_ok.connect(lambda res: self.table.setItem(row, 3, QTableWidgetItem(res.get("ip", "?"))))
        worker.finished_err.connect(lambda err: self.table.setItem(row, 3, QTableWidgetItem("error")))
        self._workers.append(worker)
        worker.start()

    def _on_error(self, err):
        self.status_label.setText(f"Error: {err}")
        QMessageBox.critical(self, "Error", err)
