"""
Chain Wizard: automates the vpn_chain.sh workflow -- build N nested namespaces
and launch a VPN/proxy tunnel in each hop automatically, then shows a live
visual dashboard: Host -> hop1 -> hop2 -> ... -> App
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QGroupBox,
    QFormLayout, QComboBox, QLineEdit, QSpinBox, QListWidget, QListWidgetItem,
    QMessageBox, QScrollArea, QFrame, QCheckBox
)
from PyQt6.QtCore import Qt

from netgui.gui.workers import HelperWorker
from netgui.core.presets import PRESETS
from netgui.core import profiles as profile_store


class HopConfigWidget(QFrame):
    """One hop in the chain: pick tunnel type + parameters."""
    def __init__(self, index, parent=None):
        super().__init__(parent)
        self.index = index
        self.setFrameShape(QFrame.Shape.Box)
        layout = QFormLayout(self)

        self.type_combo = QComboBox()
        self.type_combo.addItems(["forticlient", "openconnect", "openvpn", "psiphon", "nekoray"])
        self.type_combo.currentTextChanged.connect(self._refresh_fields)

        self.config_path = QLineEdit()
        self.config_path.setPlaceholderText("~/Pictures/its_vpn.config")
        # OpenConnect defaults pre-filled for quick testing -- replace with real values.
        self.server = QLineEdit("https://85.158.57.32:4439")
        self.username = QLineEdit("agreeable.flea.gvgq@letterhaven.net")
        self.password = QLineEdit("12345678")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.insecure_check = QCheckBox("Accept expired/self-signed certificate (insecure)")
        self.insecure_check.setChecked(True)
        self.binary_path = QLineEdit()
        self.binary_path.setPlaceholderText("~/opt/nekoray/nekoray.AppImage")
        self.socks_port = QSpinBox()
        self.socks_port.setRange(1, 65535)
        self.socks_port.setValue(1081)
        self.region = QLineEdit("any")
        self.extra_args = QLineEdit()
        self.extra_args.setPlaceholderText(
            '--servercert pin-sha256:... (extra CLI flags appended to the command)')

        layout.addRow(f"Hop {index + 1} type:", self.type_combo)

        self.profile_combo = QComboBox()
        self.profile_combo.addItem("(none)", None)
        load_profile_btn = QPushButton("Load")
        load_profile_btn.clicked.connect(self._load_selected_profile)
        profile_row = QHBoxLayout()
        profile_row.addWidget(self.profile_combo)
        profile_row.addWidget(load_profile_btn)
        layout.addRow("Saved profile:", profile_row)
        self._refresh_profile_list()

        self.dynamic_row_start = layout.rowCount()
        layout.addRow("Config path:", self.config_path)
        layout.addRow("Server:", self.server)
        layout.addRow("Username:", self.username)
        layout.addRow("Password:", self.password)
        layout.addRow("", self.insecure_check)
        layout.addRow("Binary path:", self.binary_path)
        layout.addRow("SOCKS port:", self.socks_port)
        layout.addRow("Region:", self.region)
        layout.addRow("Extra arguments:", self.extra_args)
        self._form = layout
        self._refresh_fields(self.type_combo.currentText())
        self.type_combo.currentTextChanged.connect(lambda _: self._refresh_profile_list())

    def _refresh_fields(self, kind):
        mapping = {
            "forticlient": ["config_path", "extra_args"],
            "openconnect": ["server", "username", "password", "insecure_check", "extra_args"],
            "openvpn": ["config_path", "username", "password", "extra_args"],
            "psiphon": ["binary_path", "socks_port", "region", "extra_args"],
            "nekoray": ["binary_path", "socks_port", "extra_args"],
        }
        visible = set(mapping.get(kind, []))
        for name in ["config_path", "server", "username", "password", "insecure_check",
                     "binary_path", "socks_port", "region", "extra_args"]:
            widget = getattr(self, name)
            label = self._form.labelForField(widget)
            show = name in visible
            widget.setVisible(show)
            if label:
                label.setVisible(show)

    def _refresh_profile_list(self):
        kind = self.type_combo.currentText()
        current = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItem("(none)", None)
        for p in profile_store.load_profiles():
            if p.get("type") == kind:
                self.profile_combo.addItem(p["name"], p)
        self.profile_combo.blockSignals(False)

    def _load_selected_profile(self):
        p = self.profile_combo.currentData()
        if not p:
            return
        self.config_path.setText(p.get("config_path", ""))
        self.server.setText(p.get("server", ""))
        self.username.setText(p.get("username", ""))
        self.binary_path.setText(p.get("binary_path", ""))
        if p.get("region"):
            self.region.setText(p.get("region"))
        # Password is intentionally never stored in profiles for security reasons.

    def to_args(self):
        kind = self.type_combo.currentText()
        args = {"type": kind}
        if kind == "forticlient":
            args["config_path"] = self.config_path.text().strip()
        elif kind == "openconnect":
            args["server"] = self.server.text().strip()
            args["username"] = self.username.text().strip()
            args["password"] = self.password.text()
            args["insecure"] = self.insecure_check.isChecked()
        elif kind == "psiphon":
            args["binary_path"] = self.binary_path.text().strip() or None
            args["socks_port"] = self.socks_port.value()
            args["region"] = self.region.text().strip() or "any"
        elif kind == "openvpn":
            args["config_path"] = self.config_path.text().strip()
            args["username"] = self.username.text().strip() or None
            args["password"] = self.password.text() or None
        elif kind == "nekoray":
            args["binary_path"] = self.binary_path.text().strip()
            args["socks_port"] = self.socks_port.value()
        args["extra_args"] = self.extra_args.text().strip()
        return args


class ChainWizardTab(QWidget):
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self.hop_widgets = []
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        preset_box = QGroupBox("Quick Presets")
        preset_layout = QHBoxLayout(preset_box)
        self.preset_combo = QComboBox()
        for p in PRESETS:
            self.preset_combo.addItem(p["label"], p["id"])
        apply_btn = QPushButton("Apply Preset")
        apply_btn.clicked.connect(self.apply_preset)
        preset_layout.addWidget(self.preset_combo)
        preset_layout.addWidget(apply_btn)
        layout.addWidget(preset_box)

        config_box = QGroupBox("Chain Configuration")
        config_layout = QVBoxLayout(config_box)

        hop_count_row = QHBoxLayout()
        hop_count_row.addWidget(QLabel("Number of hops:"))
        self.hop_count_spin = QSpinBox()
        self.hop_count_spin.setRange(1, 6)
        self.hop_count_spin.setValue(1)
        self.hop_count_spin.valueChanged.connect(self._rebuild_hops)
        hop_count_row.addWidget(self.hop_count_spin)
        hop_count_row.addStretch()
        config_layout.addLayout(hop_count_row)

        self.hops_container = QVBoxLayout()
        config_layout.addLayout(self.hops_container)
        self._rebuild_hops(1)

        run_row = QHBoxLayout()
        self.run_btn = QPushButton("Build Chain and Connect")
        self.run_btn.clicked.connect(self.run_chain)
        self.teardown_btn = QPushButton("Tear Down Chain")
        self.teardown_btn.clicked.connect(self.teardown_chain)
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.teardown_btn)
        config_layout.addLayout(run_row)

        layout.addWidget(config_box)

        dash_box = QGroupBox("Live Chain Dashboard")
        dash_layout = QVBoxLayout(dash_box)
        self.dashboard_label = QLabel("Host")
        self.dashboard_label.setWordWrap(True)
        self.dashboard_label.setStyleSheet("font-size: 15px; padding: 12px;")
        dash_layout.addWidget(self.dashboard_label)
        layout.addWidget(dash_box)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)
        layout.addStretch()

    def _rebuild_hops(self, count):
        while self.hops_container.count():
            item = self.hops_container.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self.hop_widgets = []
        for i in range(count):
            hop = HopConfigWidget(i)
            self.hops_container.addWidget(hop)
            self.hop_widgets.append(hop)

    def apply_preset(self):
        preset_id = self.preset_combo.currentData()
        preset = next((p for p in PRESETS if p["id"] == preset_id), None)
        if not preset:
            return
        self.hop_count_spin.setValue(len(preset["chain"]))
        for hop_widget, hop_cfg in zip(self.hop_widgets, preset["chain"]):
            hop_widget.type_combo.setCurrentText(hop_cfg["type"])

    def run_chain(self):
        base_name = "chain"
        n_hops = len(self.hop_widgets)
        self.chain_ns_names = [f"{base_name}-{i+1}" for i in range(n_hops)]
        self._create_hop_ns(0)

    def _create_hop_ns(self, i):
        if i >= len(self.chain_ns_names):
            self.status_label.setText("All namespaces created. Launching tunnels...")
            self._start_hop_tunnel(0)
            return
        name = self.chain_ns_names[i]
        parent = self.chain_ns_names[i - 1] if i > 0 else None
        subnet = 200 + i
        args = {
            "name": name, "parent": parent,
            "host_ip": f"10.{subnet}.0.1", "ns_ip": f"10.{subnet}.0.2",
            "dns": ["1.1.1.1", "8.8.8.8"],
        }
        self.status_label.setText(f"Creating namespace {name} ({i+1}/{len(self.chain_ns_names)})...")
        worker = HelperWorker("create_namespace", args)
        worker.finished_ok.connect(lambda res, idx=i: self._create_hop_ns(idx + 1))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def _start_hop_tunnel(self, i):
        if i >= len(self.hop_widgets):
            self.status_label.setText("Chain fully connected.")
            self._update_dashboard(connected=True)
            self.app_state.request_refresh()
            return
        ns_name = self.chain_ns_names[i]
        args = dict(self.hop_widgets[i].to_args())
        args["namespace"] = ns_name
        args["id"] = f"{ns_name}-tunnel"
        self.status_label.setText(f"Starting tunnel in {ns_name}...")
        worker = HelperWorker("start_tunnel", args)
        worker.finished_ok.connect(lambda res, idx=i: self._start_hop_tunnel(idx + 1))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def teardown_chain(self):
        names = getattr(self, "chain_ns_names", None)
        if not names:
            return
        outer = names[0]
        worker = HelperWorker("delete_namespace", {"name": outer})
        worker.finished_ok.connect(lambda res: (self.status_label.setText("Chain torn down."),
                                                  self._update_dashboard(connected=False),
                                                  self.app_state.request_refresh()))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def _update_dashboard(self, connected: bool):
        names = getattr(self, "chain_ns_names", [])
        icon = "\U0001F7E2" if connected else "\u26AA"
        parts = ["Host " + icon]
        for name in names:
            parts.append(f"-> {name} {icon}")
        parts.append("-> App " + icon)
        self.dashboard_label.setText("  ".join(parts))

    def _on_error(self, err):
        self.status_label.setText(f"Error: {err}")
        QMessageBox.critical(self, "Error", err)
