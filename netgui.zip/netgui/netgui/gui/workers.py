"""QThread workers so pkexec/helper calls (which block and may show a GUI
password prompt) never freeze the Qt main thread."""
from PyQt6.QtCore import QThread, pyqtSignal

from netgui.core.bridge_client import call, HelperError


class HelperWorker(QThread):
    finished_ok = pyqtSignal(dict)
    finished_err = pyqtSignal(str)

    def __init__(self, action: str, args: dict | None = None, parent=None):
        super().__init__(parent)
        self.action = action
        self.args = args or {}

    def run(self):
        try:
            result = call(self.action, self.args)
            if result.get("ok", False):
                self.finished_ok.emit(result)
            else:
                self.finished_err.emit(result.get("error", "Unknown error"))
        except HelperError as e:
            self.finished_err.emit(str(e))
        except Exception as e:
            self.finished_err.emit(str(e))


class PollWorker(QThread):
    """Periodically polls list_namespaces without pkexec (reads state.json directly)."""
    tick = pyqtSignal(dict)

    def __init__(self, interval_ms=3000, parent=None):
        super().__init__(parent)
        self.interval_ms = interval_ms
        self._running = True
        self._force = False

    def stop(self):
        self._running = False

    def force_tick(self):
        self._force = True

    def run(self):
        import json, subprocess, time
        from netgui.core.constants import STATE_FILE
        while self._running:
            state = {"namespaces": {}, "tunnels": {}, "bridges": {}, "proxies": {}}
            try:
                out = subprocess.run(["ip", "netns", "list"], stdout=subprocess.PIPE, text=True)
                live = [l.split()[0] for l in out.stdout.splitlines() if l.strip()]
                try:
                    with open(STATE_FILE) as f:
                        disk_state = json.load(f)
                except Exception:
                    disk_state = {"namespaces": {}, "tunnels": {}, "bridges": {}, "proxies": {}}
                for name in live:
                    state["namespaces"][name] = disk_state.get("namespaces", {}).get(name, {})
                state["tunnels"] = disk_state.get("tunnels", {})
                state["bridges"] = disk_state.get("bridges", {})
                state["proxies"] = disk_state.get("proxies", {})
            except Exception:
                pass
            self.tick.emit(state)
            for _ in range(self.interval_ms // 100):
                if not self._running or self._force:
                    self._force = False
                    break
                time.sleep(0.1)
