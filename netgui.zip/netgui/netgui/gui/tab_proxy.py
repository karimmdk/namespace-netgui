"""Proxy Manager: start the built-in SOCKS5 proxy server inside any
namespace (so it uses that namespace's VPN/tunnel), then optionally bridge
it to a host port so normal apps (browsers, curl, etc.) running outside any
namespace can point their SOCKS5 settings at 127.0.0.1:<host_port> and
transparently go through the VPN."""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox,
    QGroupBox, QFormLayout, QSpinBox, QTableWidget, QTableWidgetItem,
    QMessageBox, QHeaderView, QCheckBox
)

from netgui.gui.workers import HelperWorker


class ProxyTab(QWidget):
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        form_box = QGroupBox("Start SOCKS5 Proxy in Namespace")
        form = QFormLayout(form_box)
        self.ns_combo = QComboBox()
        self.proxy_port = QSpinBox()
        self.proxy_port.setRange(1, 65535)
        self.proxy_port.setValue(1080)
        self.also_bridge = QCheckBox("Also expose on host (127.0.0.1) at a chosen port")
        self.also_bridge.setChecked(True)
        self.host_port = QSpinBox()
        self.host_port.setRange(1, 65535)
        self.host_port.setValue(3080)

        form.addRow("Namespace:", self.ns_combo)
        form.addRow("Proxy port (inside namespace):", self.proxy_port)
        form.addRow("", self.also_bridge)
        form.addRow("Host port (127.0.0.1:...):", self.host_port)

        start_btn = QPushButton("Start Proxy")
        start_btn.clicked.connect(self.on_start)
        form.addRow(start_btn)
        layout.addWidget(form_box)

        info = QLabel(
            "After starting, point any app's SOCKS5 proxy setting at "
            "127.0.0.1:<host port> shown in the table below. This works for "
            "browsers, curl (--socks5 127.0.0.1:PORT), torrent clients, etc. "
            "Note: SOCKS5 proxies only tunnel TCP -- some apps also need a "
            "separate DNS-over-proxy setting to avoid DNS leaks."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        table_box = QGroupBox("Active Proxies")
        tlayout = QVBoxLayout(table_box)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Namespace", "Proxy Port (ns)", "Bridged Host Port", "Address to use", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tlayout.addWidget(self.table)
        layout.addWidget(table_box)

        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

        self._proxy_meta = {}
        self._bridge_meta = {}

    def refresh(self, state: dict):
        namespaces = state.get("namespaces", {})
        current = self.ns_combo.currentText()
        self.ns_combo.blockSignals(True)
        self.ns_combo.clear()
        for name in namespaces:
            self.ns_combo.addItem(name)
        idx = self.ns_combo.findText(current)
        if idx >= 0:
            self.ns_combo.setCurrentIndex(idx)
        self.ns_combo.blockSignals(False)

        proxies = state.get("proxies", {})
        bridges = state.get("bridges", {})
        self._proxy_meta = proxies
        self._bridge_meta = bridges

        # find a bridge whose target_port matches a proxy's port in the same namespace
        self.table.setRowCount(0)
        for proxy_id, meta in proxies.items():
            row = self.table.rowCount()
            self.table.insertRow(row)
            ns = meta.get("namespace", "")
            port = meta.get("port", "")
            matching_bridge = None
            matching_bridge_id = None
            for bid, b in bridges.items():
                if b.get("namespace") == ns and b.get("target_port") == port:
                    matching_bridge = b
                    matching_bridge_id = bid
                    break
            host_port_str = str(matching_bridge.get("host_port")) if matching_bridge else "(not bridged)"
            address_str = f"127.0.0.1:{matching_bridge.get('host_port')}" if matching_bridge else "-"

            self.table.setItem(row, 0, QTableWidgetItem(ns))
            self.table.setItem(row, 1, QTableWidgetItem(str(port)))
            self.table.setItem(row, 2, QTableWidgetItem(host_port_str))
            self.table.setItem(row, 3, QTableWidgetItem(address_str))

            remove_btn = QPushButton("Stop")
            remove_btn.clicked.connect(
                lambda _, pid=proxy_id, bid=matching_bridge_id: self.on_stop(pid, bid))
            self.table.setCellWidget(row, 4, remove_btn)

    def on_start(self):
        ns = self.ns_combo.currentText()
        if not ns:
            QMessageBox.warning(self, "No namespace", "Create a namespace first.")
            return
        port = self.proxy_port.value()
        host_port = self.host_port.value()
        bridge_after = self.also_bridge.isChecked()

        self.status_label.setText(f"Starting SOCKS5 proxy on port {port} inside '{ns}'...")
        worker = HelperWorker("start_proxy", {"namespace": ns, "port": port})

        def on_ok(res):
            if bridge_after:
                self._start_bridge(ns, port, host_port)
            else:
                self.status_label.setText(
                    f"Proxy started inside '{ns}' on port {port} (not exposed to host).")
                self.app_state.request_refresh()

        worker.finished_ok.connect(on_ok)
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def _start_bridge(self, ns, target_port, host_port):
        bridge_worker = HelperWorker(
            "add_bridge", {"namespace": ns, "target_port": target_port, "host_port": host_port})
        bridge_worker.finished_ok.connect(
            lambda res: (self.status_label.setText(
                f"Proxy ready! Use 127.0.0.1:{host_port} as your SOCKS5 proxy address."),
                self.app_state.request_refresh()))
        bridge_worker.finished_err.connect(
            lambda err: self.status_label.setText(
                f"Proxy started inside the namespace, but bridging to the host failed: {err}"))
        self._workers.append(bridge_worker)
        bridge_worker.start()

    def on_stop(self, proxy_id, bridge_id):
        worker = HelperWorker("stop_proxy", {"proxy_id": proxy_id})
        worker.finished_ok.connect(lambda res: self._after_stop(bridge_id))
        worker.finished_err.connect(self._on_error)
        self._workers.append(worker)
        worker.start()

    def _after_stop(self, bridge_id):
        self.status_label.setText("Proxy stopped.")
        if bridge_id:
            bworker = HelperWorker("remove_bridge", {"bridge_id": bridge_id})
            bworker.finished_ok.connect(lambda res: self.app_state.request_refresh())
            bworker.finished_err.connect(lambda err: None)
            self._workers.append(bworker)
            bworker.start()
        else:
            self.app_state.request_refresh()

    def _on_error(self, err):
        self.status_label.setText(f"Error: {err}")
        QMessageBox.critical(self, "Error", err)
