from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox,
    QGroupBox, QFormLayout, QTextEdit, QMessageBox, QLineEdit
)
from PyQt6.QtCore import QTimer

from netgui.gui.workers import HelperWorker


class DiagnosticsTab(QWidget):
    """IP test, IP/DNS leak test, live tunnel log viewer (with clear log and
    interactive-prompt popup support), and app launcher inside a chosen
    namespace."""
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._workers = []
        self._log_timer = QTimer(self)
        self._log_timer.timeout.connect(self._tail_log)
        self._current_log_path = None
        self._current_tunnel_id = None
        self._log_offset = 0
        self._tunnel_logs = {}     # label -> log path
        self._tunnel_ids = {}      # label -> tunnel_id
        self._known_ns = []
        self._known_log_labels = []
        self._prompt_open = False
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        top_box = QGroupBox("Namespace Diagnostics")
        form = QFormLayout(top_box)
        self.ns_combo = QComboBox()
        form.addRow("Namespace:", self.ns_combo)

        btn_row = QHBoxLayout()
        ip_btn = QPushButton("Test Public IP")
        ip_btn.clicked.connect(self.on_test_ip)
        ping_btn = QPushButton("Ping 8.8.8.8")
        ping_btn.clicked.connect(self.on_ping_test)
        leak_btn = QPushButton("Run IP/DNS Leak Test")
        leak_btn.clicked.connect(self.on_leak_test)
        btn_row.addWidget(ip_btn)
        btn_row.addWidget(ping_btn)
        btn_row.addWidget(leak_btn)
        form.addRow(btn_row)
        layout.addWidget(top_box)

        launcher_box = QGroupBox("App Launcher (run inside namespace)")
        launcher_form = QFormLayout(launcher_box)
        self.app_input = QLineEdit()
        self.app_input.setPlaceholderText("firefox / chromium / code / xterm ...")
        launch_btn = QPushButton("Launch")
        launch_btn.clicked.connect(self.on_launch)
        launcher_form.addRow("Command:", self.app_input)
        launcher_form.addRow(launch_btn)
        layout.addWidget(launcher_box)

        log_box = QGroupBox("Live Log Viewer")
        log_layout = QVBoxLayout(log_box)
        log_top_row = QHBoxLayout()
        self.log_ns_combo = QComboBox()
        self.log_ns_combo.currentTextChanged.connect(self._on_log_ns_changed)
        log_top_row.addWidget(self.log_ns_combo)
        clear_log_btn = QPushButton("Clear Log")
        clear_log_btn.clicked.connect(self.on_clear_log)
        log_top_row.addWidget(clear_log_btn)
        log_layout.addLayout(log_top_row)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        log_layout.addWidget(self.log_view)

        answer_row = QHBoxLayout()
        self.manual_answer_input = QLineEdit()
        self.manual_answer_input.setPlaceholderText(
            "Type an answer for an interactive prompt (e.g. yes) and press Send")
        send_answer_btn = QPushButton("Send")
        send_answer_btn.clicked.connect(self.on_send_manual_answer)
        answer_row.addWidget(self.manual_answer_input)
        answer_row.addWidget(send_answer_btn)
        log_layout.addLayout(answer_row)

        layout.addWidget(log_box)

        self.result_view = QTextEdit()
        self.result_view.setReadOnly(True)
        self.result_view.setMaximumHeight(120)
        layout.addWidget(self.result_view)

    def refresh(self, state: dict):
        namespaces = list(state.get("namespaces", {}).keys())
        if namespaces != self._known_ns:
            self._known_ns = namespaces
            current = self.ns_combo.currentText()
            self.ns_combo.blockSignals(True)
            self.ns_combo.clear()
            self.ns_combo.addItems(namespaces)
            idx = self.ns_combo.findText(current)
            if idx >= 0:
                self.ns_combo.setCurrentIndex(idx)
            self.ns_combo.blockSignals(False)

        tunnels = state.get("tunnels", {})
        new_logs = {}
        new_ids = {}
        for tid, meta in tunnels.items():
            label = f"{tid} ({meta.get('type')})"
            new_logs[label] = meta.get("log")
            new_ids[label] = tid

        new_labels = sorted(new_logs.keys())
        if new_labels != self._known_log_labels:
            self._known_log_labels = new_labels
            self._tunnel_logs = new_logs
            self._tunnel_ids = new_ids
            current_label = self.log_ns_combo.currentText()
            self.log_ns_combo.blockSignals(True)
            self.log_ns_combo.clear()
            self.log_ns_combo.addItems(new_labels)
            idx = self.log_ns_combo.findText(current_label)
            if idx >= 0:
                self.log_ns_combo.setCurrentIndex(idx)
            elif new_labels:
                self.log_ns_combo.setCurrentIndex(0)
            self.log_ns_combo.blockSignals(False)
            new_path = self._tunnel_logs.get(self.log_ns_combo.currentText())
            self._current_tunnel_id = self._tunnel_ids.get(self.log_ns_combo.currentText())
            if new_path != self._current_log_path:
                self._attach_log(new_path)
        else:
            # tunnel list unchanged -- keep tailing the same file, do NOT touch the view
            self._tunnel_logs = new_logs
            self._tunnel_ids = new_ids

    def _on_log_ns_changed(self, label):
        path = self._tunnel_logs.get(label)
        self._current_tunnel_id = self._tunnel_ids.get(label)
        self._attach_log(path)

    def _attach_log(self, path):
        if path == self._current_log_path:
            return
        self._current_log_path = path
        self._log_offset = 0
        self.log_view.clear()
        if path:
            self._log_timer.start(1000)
            self._tail_log()
        else:
            self._log_timer.stop()

    def on_clear_log(self):
        """Truncate the currently viewed log file on disk and clear the
        viewer. This does not stop the tunnel -- it only clears old output."""
        if not self._current_log_path:
            self.log_view.clear()
            return
        try:
            open(self._current_log_path, "w").close()
        except Exception as e:
            QMessageBox.warning(self, "Could not clear log file", str(e))
        self._log_offset = 0
        self.log_view.clear()

    # Known interactive prompts that VPN CLI tools may print and block on.
    # If any of these substrings appear in freshly-tailed log output, we pop
    # up a confirmation dialog so the user can answer without touching a
    # terminal.
    _PROMPT_PATTERNS = [
        ("Enter 'yes' to accept, 'no' to abort", "yes"),
        ("Continue connecting", "yes"),
        ("Accept?", "yes"),
    ]

    def _tail_log(self):
        if not self._current_log_path:
            return
        try:
            with open(self._current_log_path, "r", errors="ignore") as f:
                f.seek(self._log_offset)
                chunk = f.read()
                self._log_offset = f.tell()
            if chunk:
                sb = self.log_view.verticalScrollBar()
                was_at_bottom = sb.value() >= sb.maximum() - 4
                self.log_view.moveCursor(self.log_view.textCursor().MoveOperation.End)
                self.log_view.insertPlainText(chunk)
                if was_at_bottom:
                    sb.setValue(sb.maximum())
                self._check_for_prompt(chunk)
        except FileNotFoundError:
            pass

    def _check_for_prompt(self, chunk):
        if self._prompt_open or not self._current_tunnel_id:
            return
        for pattern, default_answer in self._PROMPT_PATTERNS:
            if pattern in chunk:
                self._prompt_open = True
                answer = QMessageBox.question(
                    self, "Tunnel is asking a question",
                    f"The tunnel process is waiting for input:\n\n\"{pattern}\"\n\n"
                    f"Send \"{default_answer}\" to it now?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                )
                if answer == QMessageBox.StandardButton.Yes:
                    self._send_input(self._current_tunnel_id, default_answer)
                self._prompt_open = False
                break

    def _send_input(self, tunnel_id, text):
        worker = HelperWorker("send_tunnel_input", {"tunnel_id": tunnel_id, "text": text})
        worker.finished_ok.connect(lambda res: self.result_view.setPlainText(f"Sent '{text}' to tunnel."))
        worker.finished_err.connect(lambda err: self.result_view.setPlainText(f"Failed to send input: {err}"))
        self._workers.append(worker)
        worker.start()

    def on_send_manual_answer(self):
        text = self.manual_answer_input.text().strip()
        if not text or not self._current_tunnel_id:
            QMessageBox.information(self, "Nothing to send",
                                     "Select a tunnel log and type an answer first.")
            return
        self._send_input(self._current_tunnel_id, text)
        self.manual_answer_input.clear()

    def on_test_ip(self):
        ns = self.ns_combo.currentText()
        if not ns:
            QMessageBox.warning(self, "No namespace", "Select a namespace first.")
            return
        self.result_view.setPlainText(f"Testing IP for '{ns}'...")
        worker = HelperWorker("test_ip", {"namespace": ns})
        worker.finished_ok.connect(lambda res: self.result_view.setPlainText("Public IP: %s" % res.get("ip", "?")))
        worker.finished_err.connect(lambda err: self.result_view.setPlainText(f"ERROR: {err}"))
        self._workers.append(worker)
        worker.start()

    def on_ping_test(self):
        ns = self.ns_combo.currentText()
        if not ns:
            QMessageBox.warning(self, "No namespace", "Select a namespace first.")
            return
        self.result_view.setPlainText(f"Pinging 8.8.8.8 from '{ns}'...")
        worker = HelperWorker("ping_test", {"namespace": ns, "target": "8.8.8.8"})
        worker.finished_ok.connect(lambda res: self.result_view.setPlainText(str(res.get("result"))))
        worker.finished_err.connect(lambda err: self.result_view.setPlainText(f"ERROR: {err}"))
        self._workers.append(worker)
        worker.start()

    def on_leak_test(self):
        ns = self.ns_combo.currentText()
        if not ns:
            return
        self.result_view.setPlainText("Running leak test...")
        worker = HelperWorker("leak_test", {"namespace": ns})
        worker.finished_ok.connect(lambda res: self.result_view.setPlainText(str(res.get("result"))))
        worker.finished_err.connect(lambda err: self.result_view.setPlainText(f"Error: {err}"))
        self._workers.append(worker)
        worker.start()

    def on_launch(self):
        ns = self.ns_combo.currentText()
        cmd_text = self.app_input.text().strip()
        if not ns or not cmd_text:
            return
        worker = HelperWorker("launch_app", {"namespace": ns, "command": cmd_text.split()})
        worker.finished_ok.connect(lambda res: self.result_view.setPlainText("Launched PID %s" % res.get("pid")))
        worker.finished_err.connect(lambda err: self.result_view.setPlainText(f"Error: {err}"))
        self._workers.append(worker)
        worker.start()
