from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget,
    QListWidgetItem, QLineEdit, QLabel, QComboBox, QGroupBox, QFormLayout,
    QMessageBox, QFileDialog
)

from netgui.core import profiles as profile_store


class ProfilesTab(QWidget):
    """Saved VPN profiles: FortiClient config path, OpenConnect server/user,
    Psiphon region, Nekoray port -- plus Import/Export to a JSON file."""
    def __init__(self, app_state, parent=None):
        super().__init__(parent)
        self.app_state = app_state
        self._build_ui()
        self.reload_list()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        form_box = QGroupBox("New / Edit Profile")
        form = QFormLayout(form_box)
        self.name_input = QLineEdit()
        self.type_combo = QComboBox()
        self.type_combo.addItems(["forticlient", "openconnect", "openvpn", "psiphon", "nekoray"])
        self.config_path = QLineEdit()
        self.server = QLineEdit()
        self.username = QLineEdit()
        self.region = QLineEdit("any")
        self.binary_path = QLineEdit()

        form.addRow("Profile name:", self.name_input)
        form.addRow("Type:", self.type_combo)
        form.addRow("Config path (FortiClient):", self.config_path)
        form.addRow("Server (OpenConnect):", self.server)
        form.addRow("Username (OpenConnect):", self.username)
        form.addRow("Region (Psiphon):", self.region)
        form.addRow("Binary path (Psiphon/Nekoray):", self.binary_path)

        save_btn = QPushButton("Save Profile")
        save_btn.clicked.connect(self.on_save)
        form.addRow(save_btn)
        layout.addWidget(form_box)

        list_box = QGroupBox("Saved Profiles")
        list_layout = QVBoxLayout(list_box)
        self.list_widget = QListWidget()
        self.list_widget.itemClicked.connect(self.on_select)
        list_layout.addWidget(self.list_widget)

        btn_row = QHBoxLayout()
        del_btn = QPushButton("Delete Selected")
        del_btn.clicked.connect(self.on_delete)
        export_btn = QPushButton("Export All")
        export_btn.clicked.connect(self.on_export)
        import_btn = QPushButton("Import")
        import_btn.clicked.connect(self.on_import)
        btn_row.addWidget(del_btn)
        btn_row.addWidget(export_btn)
        btn_row.addWidget(import_btn)
        list_layout.addLayout(btn_row)

        layout.addWidget(list_box)
        self.status_label = QLabel("")
        layout.addWidget(self.status_label)

    def reload_list(self):
        self.list_widget.clear()
        for p in profile_store.load_profiles():
            item = QListWidgetItem("%s (%s)" % (p["name"], p["type"]))
            item.setData(1, p)
            self.list_widget.addItem(item)

    def on_save(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing name", "Enter a profile name.")
            return
        profile = {
            "name": name, "type": self.type_combo.currentText(),
            "config_path": self.config_path.text().strip(),
            "server": self.server.text().strip(),
            "username": self.username.text().strip(),
            "region": self.region.text().strip() or "any",
            "binary_path": self.binary_path.text().strip(),
        }
        profile_store.add_profile(profile)
        self.status_label.setText(f"Profile '{name}' saved.")
        self.reload_list()

    def on_select(self, item):
        p = item.data(1)
        self.name_input.setText(p.get("name", ""))
        self.type_combo.setCurrentText(p.get("type", "forticlient"))
        self.config_path.setText(p.get("config_path", ""))
        self.server.setText(p.get("server", ""))
        self.username.setText(p.get("username", ""))
        self.region.setText(p.get("region", "any"))
        self.binary_path.setText(p.get("binary_path", ""))

    def on_delete(self):
        item = self.list_widget.currentItem()
        if not item:
            return
        p = item.data(1)
        profile_store.delete_profile(p["name"])
        self.reload_list()
        self.status_label.setText("Profile '%s' deleted." % p["name"])

    def on_export(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export profiles", "netgui-profiles.json", "JSON (*.json)")
        if path:
            profile_store.export_profiles(path)
            self.status_label.setText(f"Exported to {path}")

    def on_import(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import profiles", "", "JSON (*.json)")
        if path:
            profile_store.import_profiles(path, merge=True)
            self.reload_list()
            self.status_label.setText(f"Imported from {path}")
