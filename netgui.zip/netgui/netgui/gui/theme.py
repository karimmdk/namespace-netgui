DARK_QSS = """
QWidget { background-color: #1e1f26; color: #e6e6e6; font-size: 13px; }
QMainWindow { background-color: #1e1f26; }
QTabWidget::pane { border: 1px solid #33343f; }
QTabBar::tab { background: #262832; padding: 8px 16px; color: #cfcfcf; }
QTabBar::tab:selected { background: #3a3d4d; color: white; }
QPushButton { background-color: #3a3d4d; border: 1px solid #4a4d5f; border-radius: 4px; padding: 6px 12px; }
QPushButton:hover { background-color: #4a4d5f; }
QPushButton:disabled { background-color: #2a2b33; color: #6d6d6d; }
QLineEdit, QComboBox, QSpinBox, QTextEdit, QPlainTextEdit, QListWidget, QTableWidget {
    background-color: #262832; border: 1px solid #3a3d4d; border-radius: 3px; padding: 4px; color: #e6e6e6;
}
QHeaderView::section { background-color: #2a2b33; color: #cfcfcf; padding: 4px; border: none; }
QGroupBox { border: 1px solid #3a3d4d; border-radius: 4px; margin-top: 10px; padding-top: 10px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QLabel#StatusOk { color: #4caf50; font-weight: bold; }
QLabel#StatusBad { color: #e53935; font-weight: bold; }
QLabel#StatusWarn { color: #ffb300; font-weight: bold; }
"""

LIGHT_QSS = """
QWidget { background-color: #fafafa; color: #202020; font-size: 13px; }
QTabBar::tab { background: #eeeeee; padding: 8px 16px; }
QTabBar::tab:selected { background: #ffffff; border: 1px solid #cccccc; }
QPushButton { background-color: #e0e0e0; border: 1px solid #bdbdbd; border-radius: 4px; padding: 6px 12px; }
QPushButton:hover { background-color: #d5d5d5; }
QLineEdit, QComboBox, QSpinBox, QTextEdit, QPlainTextEdit, QListWidget, QTableWidget {
    background-color: #ffffff; border: 1px solid #cccccc; border-radius: 3px; padding: 4px;
}
QGroupBox { border: 1px solid #cccccc; border-radius: 4px; margin-top: 10px; padding-top: 10px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QLabel#StatusOk { color: #2e7d32; font-weight: bold; }
QLabel#StatusBad { color: #c62828; font-weight: bold; }
QLabel#StatusWarn { color: #ef6c00; font-weight: bold; }
"""
