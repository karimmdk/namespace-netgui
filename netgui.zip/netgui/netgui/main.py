import sys
from PyQt6.QtWidgets import QApplication

from netgui.gui.main_window import MainWindow
from netgui.gui.theme import DARK_QSS


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(DARK_QSS)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
