#!/usr/bin/env python3
"""
Standalone launcher -- run NetGUI directly with `python3 run.py`
without installing the package (no pip install, no pipx needed).

Requirements: PyQt6 must be importable (install via pacman or pip).
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from netgui.main import main

if __name__ == "__main__":
    main()
