# NetGUI — VPN Namespace & Chain Manager

A native PyQt6 GUI for Arch Linux that replaces `vpn_namespace_builder.sh` and `vpn_chain.sh`
with a graphical, multi-namespace, chain-aware VPN/proxy manager.

## Features

- Create/delete unlimited network namespaces, link them host<->ns or ns<->ns (nested chains)
- Run FortiClient (openfortivpn), OpenConnect, OpenVPN, Psiphon, or Nekoray inside any namespace
- Auto "Quick Chain" wizard: builds nested namespaces and launches tunnels in one flow (vpn_chain.sh style)
- Port-bridge manager (socat) to expose an inner namespace's SOCKS/HTTP proxy on the host
- Live visual chain dashboard: Host -> vpn-out -> vpn-in -> App with live status icons
- Real-time IP test (curl ifconfig.me) per namespace + IP/DNS leak test
- Live log viewer (tail -f style) for every tunnel process
- Saved VPN profiles (FortiClient config path, OpenConnect server/user, OpenVPN config, Psiphon region, Nekoray port) + Import/Export -- loadable directly into any Chain Wizard hop with one click (password is never stored in a profile, for security)
- App launcher: run any binary (browser, terminal, code editor) inside a chosen namespace
- Dependency checker/installer (pacman): socat, openconnect, openfortivpn, iproute2
- Tunnel uptime tracking
- Quick presets (e.g. "FortiClient + Nekoray") with one click
- Dark/Light theme toggle, English UI

## Proxy Manager (built-in SOCKS5, no extra installs)

The Proxy tab starts a small pure-Python SOCKS5 server *inside* any namespace, so it automatically
uses whatever VPN/tunnel is active there -- no `microsocks`/`dante`/`ssh -D` dependency needed,
since it ships as part of NetGUI itself. Steps:

1. Pick the namespace whose VPN connection you want to reuse.
2. Choose a proxy port (default `1080`) -- this is internal to the namespace.
3. Leave "Also expose on host" checked and pick a host port (default `3080`).
4. Click **Start Proxy**. The table then shows the exact address to use, e.g. `127.0.0.1:3080`.
5. Point any app's SOCKS5 setting at that address -- browsers, `curl --socks5 127.0.0.1:3080 ...`,
   torrent clients, etc. -- and its traffic goes through the VPN in that namespace.

If `127.0.0.1:<host port>` did not work for you before, it was because no proxy server was ever
actually listening inside the namespace -- the Bridges tab alone only forwards a port, it does not
start anything to forward *to*. The Proxy tab now does both steps together in one click.

## Quick Start (no installation at all)

You only need Python 3.10+ and PyQt6. There is no separate "install the helper"
step anymore -- the privileged backend (`netgui/core/helper.py`) is executed
directly from this folder every time via `pkexec`, so there is nothing to
copy to `/usr/local/bin` and nothing that can go out of sync after an edit.

```bash
# 1. Install PyQt6 and the network tools you plan to use (Arch Linux)
sudo pacman -S --needed python-pyqt6 iproute2 iptables polkit socat \
    openconnect openfortivpn openvpn

# 2. Run the GUI
python3 run.py
```

That's it -- two steps, done. The first time any privileged action runs
(create namespace, start tunnel, etc.), a normal pkexec graphical password
prompt appears; after that it remembers the session as usual.

Every time you want to open NetGUI again, just run `python3 run.py` from
inside this folder. If you move or rename the project folder, it still
works immediately -- nothing references a fixed installed path.

### Optional: Desktop Launcher

To launch NetGUI from your application menu instead of the terminal:

```bash
cat > ~/.local/share/applications/netgui.desktop << EOF
[Desktop Entry]
Name=NetGUI
Comment=VPN Namespace & Chain Manager
Exec=python3 $(pwd)/run.py
Icon=network-vpn
Terminal=false
Type=Application
Categories=Network;
EOF
```

## Architecture

NetGUI runs as a normal, unprivileged desktop app. Every privileged operation (namespace
creation, iptables rules, launching a tunnel inside a namespace, etc.) is delegated to a small
root helper script, `netgui-helper`, invoked on demand through **pkexec** (graphical password
prompt). No part of the GUI itself ever runs as root, and no persistent root daemon is required.

```
netgui (GUI, user)  --pkexec-->  netgui-helper (root, one-shot per action)
                                        |
                                        v
                         /run/netgui/state.json (shared status)
                         /run/netgui/logs/<name>.log (tunnel logs)
```

Long-running processes (tunnels, socat bridges) are started with `setsid`/double-fork inside the
helper so they keep running after `pkexec` itself exits. The GUI polls `state.json` and the log
files to reflect live status, uptime, and log streams.

## Requirements (Arch Linux)

```bash
sudo pacman -S --needed python-pip python-pyqt6 iproute2 iptables polkit socat openconnect openfortivpn
```

Nekoray and Psiphon binaries are optional and can be pointed to from a saved Profile.

## Uninstall

There is nothing installed on the system to remove -- just delete this project folder:

```bash
rm -rf /run/netgui /var/lib/netgui   # optional: clears saved state/logs/profiles
rm -rf /path/to/netgui-project
```

## Notes on the pkexec design

- `netgui/core/helper.py` requires root; running it directly (not via pkexec) refuses with an error unless `EUID==0`.
- No custom polkit `.policy` file is installed or required -- `pkexec` falls back to its built-in
  default authorization rule (`org.freedesktop.policykit.exec`), which already requires
  `auth_admin` (an administrator password) for any command run through it. You'll see a normal
  graphical password prompt the first time a privileged action runs each session.
- All state/log files under `/run/netgui` are created with mode `0666` by the helper so the
  unprivileged GUI can read them for live status/log display, while only the helper (running as
  root) can create namespaces, start tunnels, or modify routing tables.
- Because helper.py is invoked with its literal file path (`pkexec python3 /path/to/helper.py ...`),
  any edit you make to that file takes effect on the very next action -- no reinstall, no cache to
  clear, no version drift between "what's on disk" and "what pkexec actually runs".
## Migration from the shell scripts

| Old script | GUI equivalent |
|---|---|
| `vpn_namespace_builder.sh` mode 1/2 | Namespaces tab -> "New Namespace" / "New Child Namespace" |
| `vpn_chain.sh` menu options 1-8 | Chain Wizard tab -> pick base VPN + optional second hop |
| manual `socat` commands | Bridges tab -> "Add Bridge" |
| `ip netns exec ns curl ifconfig.me` | Namespaces tab -> "Test IP" button per row |


## Interactive Prompt Handling

Some VPN tools (like openconnect with an expired/self-signed certificate) block waiting for a 'yes/no' answer on stdin. NetGUI now uses a named pipe (FIFO) for every tunnel's stdin, so the GUI can detect these prompts live in the log viewer and pop up a Yes/No dialog to answer them -- or you can type a custom answer manually in the Live Log Viewer's send box.
