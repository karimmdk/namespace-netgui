from setuptools import setup, find_packages

setup(
    name="netgui",
    version="1.0.0",
    description="GUI manager for VPN network namespaces, chained tunnels, and proxy bridges",
    packages=find_packages(include=["netgui", "netgui.*"]),
    install_requires=["PyQt6>=6.6.0"],
    entry_points={"console_scripts": ["netgui=netgui.main:main"]},
    include_package_data=True,
    python_requires=">=3.10",
)
