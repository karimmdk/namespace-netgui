"""Quick presets: common tunnel-chain combinations, mirroring vpn_chain.sh menu."""

PRESETS = [
    {
        "id": "forticlient_only",
        "label": "FortiClient only",
        "chain": [{"type": "forticlient"}],
    },
    {
        "id": "openconnect_only",
        "label": "OpenConnect only",
        "chain": [{"type": "openconnect"}],
    },
    {
        "id": "psiphon_only",
        "label": "Psiphon only",
        "chain": [{"type": "psiphon"}],
    },
    {
        "id": "nekoray_only",
        "label": "Nekoray only",
        "chain": [{"type": "nekoray"}],
    },
    {
        "id": "forticlient_psiphon",
        "label": "FortiClient + Psiphon (chained)",
        "chain": [{"type": "forticlient"}, {"type": "psiphon"}],
    },
    {
        "id": "forticlient_nekoray",
        "label": "FortiClient + Nekoray (chained)",
        "chain": [{"type": "forticlient"}, {"type": "nekoray"}],
    },
    {
        "id": "openconnect_psiphon",
        "label": "OpenConnect + Psiphon (chained)",
        "chain": [{"type": "openconnect"}, {"type": "psiphon"}],
    },
    {
        "id": "openconnect_nekoray",
        "label": "OpenConnect + Nekoray (chained)",
        "chain": [{"type": "openconnect"}, {"type": "nekoray"}],
    },
]
