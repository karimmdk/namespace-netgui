import os

RUN_DIR = "/run/netgui"
LOG_DIR = os.path.join(RUN_DIR, "logs")
STATE_FILE = os.path.join(RUN_DIR, "state.json")
PROFILES_DIR = "/var/lib/netgui/profiles"

# The privileged helper is executed directly from *this* checkout via
# `pkexec python3 <this-path>/helper.py ...` -- there is no separate
# "install" step, no fixed /usr/local/bin copy, and therefore no way for
# the installed helper to drift out of sync with the rest of the code.
# Whatever is in netgui/core/helper.py right now is exactly what runs as
# root, every single time.
HELPER_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "helper.py")

DEFAULT_DNS = ["1.1.1.1", "8.8.8.8"]

TUNNEL_TYPES = ["forticlient", "openconnect", "openvpn", "psiphon", "nekoray", "custom"]

REQUIRED_PKGS = {
    "socat": "socat",
    "openconnect": "openconnect",
    "openfortivpn": "openfortivpn",
    "openvpn": "openvpn",
    "ip": "iproute2",
    "iptables": "iptables",
}
