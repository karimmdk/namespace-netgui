"""
Client-side wrapper that invokes the privileged helper via pkexec and parses
its JSON response. Runs in the unprivileged GUI process.

Runs helper.py DIRECTLY from this checkout with `pkexec python3
<path-to-helper.py> ...` -- no separate installed copy anywhere on the
system, so there is nothing to fall out of sync after an update. Just edit
helper.py and the very next call already uses the new code.
"""
import json
import subprocess
import shutil
import sys

from netgui.core.constants import HELPER_SCRIPT


class HelperError(RuntimeError):
    pass


def call(action: str, args: dict | None = None, timeout: int = 30) -> dict:
    """Invoke helper.py through pkexec and return the parsed JSON result."""
    if shutil.which("pkexec") is None:
        raise HelperError("pkexec not found. Install polkit.")

    payload = json.dumps({"action": action, "args": args or {}})
    # Use the *same* python interpreter running this GUI (sys.executable) so
    # this works identically whether you launch via `python3 run.py`, a
    # venv, or any other environment -- no assumptions about a system-wide
    # `python3` in root's PATH.
    cmd = ["pkexec", sys.executable, HELPER_SCRIPT, payload]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise HelperError(f"Action '{action}' timed out")

    if not proc.stdout.strip():
        raise HelperError(proc.stderr.strip() or f"No output from helper (exit {proc.returncode})")

    try:
        result = json.loads(proc.stdout.strip().splitlines()[-1])
    except Exception:
        raise HelperError(f"Malformed helper output: {proc.stdout!r} / {proc.stderr!r}")

    return result
