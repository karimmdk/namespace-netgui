#!/usr/bin/env python3
"""
helper.py — privileged backend for NetGUI.

Run directly from this file's location via pkexec -- never installed
anywhere else on the system (see netgui/core/bridge_client.py):

    pkexec python3 /path/to/netgui/core/helper.py '{"action": "create_namespace", "args": {...}}'

Accepts a single JSON command on argv[1] and prints a single JSON result to
stdout. This process performs one action and exits. Long-running child
processes (VPN tunnels, socat bridges) are detached with setsid so they
survive after this helper exits, and are tracked in /run/netgui/state.json.
"""
import json
import os
import signal
import subprocess
import sys
import time
import shutil
import pwd
import shlex

RUN_DIR = "/run/netgui"
LOG_DIR = os.path.join(RUN_DIR, "logs")
STATE_FILE = os.path.join(RUN_DIR, "state.json")
PROFILES_DIR = "/var/lib/netgui/profiles"

DEFAULT_DNS = ["1.1.1.1", "8.8.8.8"]


def ensure_dirs():
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(PROFILES_DIR, exist_ok=True)
    os.chmod(RUN_DIR, 0o777)
    os.chmod(LOG_DIR, 0o777)
    if not os.path.exists(STATE_FILE):
        save_state({"namespaces": {}, "bridges": {}, "tunnels": {}})
    os.chmod(STATE_FILE, 0o666)


def load_state():
    ensure_dirs()
    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
    except Exception:
        state = {}
    state.setdefault("namespaces", {})
    state.setdefault("bridges", {})
    state.setdefault("tunnels", {})
    state.setdefault("proxies", {})
    return state


def save_state(state):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.chmod(tmp, 0o666)
    os.replace(tmp, STATE_FILE)


def run(cmd, check=True, capture=False):
    if capture:
        return subprocess.run(cmd, check=check, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True)
    return subprocess.run(cmd, check=check)


def ns_exists(name):
    out = subprocess.run(["ip", "netns", "list"], stdout=subprocess.PIPE, text=True)
    return any(line.split()[0] == name for line in out.stdout.splitlines() if line.strip())


def write_dns_conf(ns, dns_servers):
    d = f"/etc/netns/{ns}"
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "resolv.conf"), "w") as f:
        for dns in dns_servers or DEFAULT_DNS:
            f.write(f"nameserver {dns}\n")
        f.write("options ndots:0\n")



import re

def _probe_servercert_pin(namespace, server, user, timeout=8):
    """Run openconnect briefly (no --background, no persistent stdin) just to
    trigger the certificate-verification error and capture the
    'pin-sha256:...' value openconnect suggests. Returns the pin string or
    None if the connection did not fail on a certificate problem."""
    cmd = ["ip", "netns", "exec", namespace, "openconnect", "-u", user,
           "--passwd-on-stdin", server]
    try:
        proc = subprocess.run(
            cmd, input="\n", stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=timeout,
        )
        output = proc.stdout or ""
    except subprocess.TimeoutExpired as e:
        output = (e.stdout or "") if hasattr(e, "stdout") else ""
    match = re.search(r"(pin-sha256:[A-Za-z0-9+/=]+)", output)
    return match.group(1) if match else None

def real_user_home(username):
    try:
        return pwd.getpwnam(username).pw_dir
    except Exception:
        return os.environ.get("HOME", "/root")


# ---------------------------------------------------------------------------
# Namespace management
# ---------------------------------------------------------------------------

def create_namespace(args):
    """Create a root namespace attached to the host via veth, or a child
    namespace attached to an existing parent namespace (nested chain)."""
    name = args["name"]
    parent = args.get("parent")            # None -> attach to host
    host_ip = args.get("host_ip") or "10.200.200.1"
    ns_ip = args.get("ns_ip") or "10.200.200.2"
    dns = args.get("dns") or DEFAULT_DNS

    if ns_exists(name):
        return {"ok": False, "error": f"namespace '{name}' already exists"}

    run(["ip", "netns", "add", name])
    run(["ip", "netns", "exec", name, "ip", "link", "set", "lo", "up"])

    veth_a = f"veth-{(parent or 'host')}-{name}"[:15]
    veth_b = f"veth-{name}"[:15]

    if parent:
        if not ns_exists(parent):
            run(["ip", "netns", "delete", name], check=False)
            return {"ok": False, "error": f"parent namespace '{parent}' does not exist"}
        run(["ip", "netns", "exec", parent, "ip", "link", "add", veth_a,
             "type", "veth", "peer", "name", veth_b])
        run(["ip", "netns", "exec", parent, "ip", "link", "set", veth_b, "netns", name])
        run(["ip", "netns", "exec", parent, "ip", "addr", "add", f"{host_ip}/24", "dev", veth_a])
        run(["ip", "netns", "exec", parent, "ip", "link", "set", veth_a, "up"])
        run(["ip", "netns", "exec", name, "ip", "addr", "add", f"{ns_ip}/24", "dev", veth_b])
        run(["ip", "netns", "exec", name, "ip", "link", "set", veth_b, "up"])
        run(["ip", "netns", "exec", name, "ip", "route", "add", "default", "via", host_ip, "dev", veth_b])
        run(["ip", "netns", "exec", parent, "sysctl", "-w", "net.ipv4.ip_forward=1"], capture=True)
        run(["ip", "netns", "exec", parent, "iptables", "-t", "nat", "-A", "POSTROUTING",
             "-s", f"{ns_ip}/24", "-j", "MASQUERADE"])
    else:
        run(["ip", "link", "add", veth_a, "type", "veth", "peer", "name", veth_b])
        run(["ip", "link", "set", veth_b, "netns", name])
        run(["ip", "addr", "add", f"{host_ip}/24", "dev", veth_a])
        run(["ip", "link", "set", veth_a, "up"])
        run(["ip", "netns", "exec", name, "ip", "addr", "add", f"{ns_ip}/24", "dev", veth_b])
        run(["ip", "netns", "exec", name, "ip", "link", "set", veth_b, "up"])
        run(["ip", "netns", "exec", name, "ip", "route", "add", "default", "via", host_ip, "dev", veth_b])
        run(["sysctl", "-w", "net.ipv4.ip_forward=1"], capture=True)
        run(["iptables", "-t", "nat", "-A", "POSTROUTING", "-s", f"{host_ip}/24", "-j", "MASQUERADE"])

    write_dns_conf(name, dns)

    state = load_state()
    state["namespaces"][name] = {
        "parent": parent, "host_ip": host_ip, "ns_ip": ns_ip,
        "dns": dns, "veth_a": veth_a, "veth_b": veth_b,
        "created": time.time(),
    }
    save_state(state)
    return {"ok": True, "namespace": name}


def delete_namespace(args):
    name = args["name"]
    state = load_state()

    # delete children first (recursive chain)
    children = [n for n, meta in state["namespaces"].items() if meta.get("parent") == name]
    for child in children:
        delete_namespace({"name": child})
        state = load_state()

    # kill tunnels/bridges bound to this ns
    for tid, t in list(state.get("tunnels", {}).items()):
        if t.get("namespace") == name:
            _kill_pid(t.get("pid"))
            fifo = t.get("fifo")
            if fifo and os.path.exists(fifo):
                os.remove(fifo)
            state["tunnels"].pop(tid, None)
    for bid, b in list(state.get("bridges", {}).items()):
        if b.get("namespace") == name:
            _kill_pid(b.get("pid"))
            state["bridges"].pop(bid, None)
    for pxid, p in list(state.get("proxies", {}).items()):
        if p.get("namespace") == name:
            _kill_pid(p.get("pid"))
            state["proxies"].pop(pxid, None)

    if ns_exists(name):
        subprocess.run(["pkill", "-9", "-f", f"ip netns exec {name}"], check=False)
        pids = subprocess.run(["ip", "netns", "pids", name], stdout=subprocess.PIPE, text=True)
        for pid in pids.stdout.split():
            _kill_pid(pid)
        run(["ip", "netns", "delete", name], check=False)

    meta = state["namespaces"].pop(name, None)
    if meta:
        host_ip = meta.get("host_ip")
        parent = meta.get("parent")
        ns_ip = meta.get("ns_ip")
        if parent:
            subprocess.run(["ip", "netns", "exec", parent, "iptables", "-t", "nat", "-D",
                             "POSTROUTING", "-s", f"{ns_ip}/24", "-j", "MASQUERADE"], check=False)
        else:
            subprocess.run(["iptables", "-t", "nat", "-D", "POSTROUTING",
                             "-s", f"{host_ip}/24", "-j", "MASQUERADE"], check=False)
    shutil.rmtree(f"/etc/netns/{name}", ignore_errors=True)
    save_state(state)
    return {"ok": True, "deleted": name}


def list_namespaces(args=None):
    out = subprocess.run(["ip", "netns", "list"], stdout=subprocess.PIPE, text=True)
    live = [l.split()[0] for l in out.stdout.splitlines() if l.strip()]
    state = load_state()
    result = {}
    for name in live:
        meta = state["namespaces"].get(name, {})
        result[name] = meta
    return {"ok": True, "namespaces": result, "tunnels": state.get("tunnels", {}),
            "bridges": state.get("bridges", {})}


def _kill_pid(pid):
    if not pid:
        return
    try:
        os.kill(int(pid), signal.SIGTERM)
        time.sleep(0.3)
        os.kill(int(pid), signal.SIGKILL)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Tunnel management (run VPN client inside a namespace)
# ---------------------------------------------------------------------------

def _spawn_detached(cmd, log_path, stdin_data=None, fifo_path=None):
    """Spawn a detached process. If fifo_path is given, a named pipe (FIFO)
    is created and used as stdin instead of a regular anonymous pipe. This
    lets the GUI send additional input *later* (e.g. answering an
    interactive "Enter yes to accept" prompt from openconnect) by simply
    writing more bytes into the FIFO from a totally separate process --
    something an anonymous Popen pipe cannot do once its write end is
    closed. This is what actually fixes "fgets (stdin): No such file or
    directory": that error happened because our anonymous pipe's write end
    was already closed by the time openconnect's TLS handshake finished and
    it tried to read the certificate-accept answer -- with a FIFO, the
    read end simply blocks until fresh data (or a real EOF) arrives instead
    of erroring out immediately.
    """
    logf = open(log_path, "ab", buffering=0)

    if fifo_path:
        if os.path.exists(fifo_path):
            os.remove(fifo_path)
        os.mkfifo(fifo_path)
        os.chmod(fifo_path, 0o666)
        # Open the FIFO for reading in non-blocking-then-blocking dance so
        # the child process (which opens it for writing... no, for
        # *reading* as its stdin) does not deadlock: we open our own write
        # end first (O_RDWR) purely to keep at least one writer alive so
        # the FIFO never sees a premature EOF before the GUI sends real
        # input, then hand the same path to the child as its stdin.
        keepalive_fd = os.open(fifo_path, os.O_RDWR | os.O_NONBLOCK)
        child_stdin = open(fifo_path, "rb", buffering=0)
        proc = subprocess.Popen(
            cmd, stdin=child_stdin, stdout=logf, stderr=logf, start_new_session=True,
        )
        child_stdin.close()
        if stdin_data:
            os.write(keepalive_fd, stdin_data.encode())
        # Leave keepalive_fd open and leaked intentionally (process-lifetime
        # of this short-lived helper invocation) so the FIFO has a writer
        # until the GUI (or a future send_tunnel_input call) opens it too.
        return proc.pid

    proc = subprocess.Popen(
        cmd, stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
        stdout=logf, stderr=logf, start_new_session=True,
    )
    if stdin_data:
        proc.stdin.write(stdin_data.encode())
        proc.stdin.close()
    return proc.pid


def start_tunnel(args):
    name = args["namespace"]
    kind = args["type"]
    tunnel_id = args.get("id") or f"{name}-{kind}-{int(time.time())}"
    if not ns_exists(name):
        return {"ok": False, "error": f"namespace '{name}' not found"}

    log_path = os.path.join(LOG_DIR, f"{tunnel_id}.log")
    open(log_path, "a").close()
    os.chmod(log_path, 0o666)

    stdin_data = None
    extra_args = shlex.split(args.get("extra_args", "") or "")

    if kind == "forticlient":
        cfg = args["config_path"]
        cmd = ["ip", "netns", "exec", name, "openfortivpn", "-c", cfg] + extra_args
    elif kind == "openconnect":
        server = args["server"]
        user = args["username"]
        password = args.get("password", "")
        cert = args.get("servercert")
        insecure = args.get("insecure", False)

        # IMPORTANT: do NOT use --background here. With --background,
        # openconnect forks away from our pipe and stdin becomes unusable,
        # which is exactly what produced "fgets (stdin): No such file or
        # directory" in testing. Running it directly (like the user's proven
        # manual command: `echo -e "yes\npassword" | openconnect ...`) keeps
        # our stdin pipe attached, so the accept-certificate prompt and the
        # password prompt can both be answered normally. We track this
        # foreground process's own PID -- it stays alive for the whole
        # session, exactly like it does in a manual terminal run.
        if not cert and insecure:
            cert = _probe_servercert_pin(name, server, user)
            # If we could not determine a pin (e.g. it was not a cert
            # problem), we still proceed -- some servers only need the
            # interactive "yes" answer without any pin at all.

        cmd = ["ip", "netns", "exec", name, "openconnect", "-u", user,
               "--passwd-on-stdin"]
        if cert:
            cmd += ["--servercert", cert]
        cmd += extra_args + [server]
        # Only the password is sent immediately. If the server's certificate
        # still triggers the interactive "Enter 'yes' to accept" prompt (e.g.
        # no --servercert / extra_args pin was supplied, or it didn't match),
        # the GUI detects that exact prompt text in the live log and pops up
        # a Yes/No confirmation dialog, then writes the answer directly into
        # this tunnel's FIFO via the send_tunnel_input action below -- this
        # is what actually fixes "fgets (stdin): No such file or directory",
        # since a FIFO (unlike a plain closed pipe) keeps accepting new
        # input for as long as the process runs.
        stdin_data = password + "\n"
    elif kind == "psiphon":
        home = real_user_home(args.get("run_as_user", "root"))
        binary = args.get("binary_path") or os.path.join(home, "psiphon-tunnel-core-x86_64")
        socks_port = args.get("socks_port", 1081)
        http_port = args.get("http_port", 8081)
        region = args.get("region", "any")
        cfg_path = f"/tmp/netgui-psiphon-{tunnel_id}.json"
        with open(cfg_path, "w") as f:
            json.dump({"LocalSocksPort": socks_port, "LocalHttpProxyPort": http_port,
                       "EgressRegion": region}, f)
        cmd = ["ip", "netns", "exec", name, binary, "-config", cfg_path] + extra_args
    elif kind == "nekoray":
        binary = args["binary_path"]
        cmd = ["ip", "netns", "exec", name, binary] + extra_args
    elif kind == "openvpn":
        cfg = args["config_path"]
        auth_user = args.get("username")
        auth_pass = args.get("password")
        cmd = ["ip", "netns", "exec", name, "openvpn", "--config", cfg] + extra_args
        if auth_user:
            # openvpn reads "user\npass\n" from --auth-user-pass when given
            # the special value "stdin" (supported since OpenVPN 2.4+).
            cmd += ["--auth-user-pass", "stdin"]
            stdin_data = f"{auth_user}\n{auth_pass or ''}\n"
    elif kind == "custom":
        cmd = ["ip", "netns", "exec", name] + args["command"] + extra_args
    else:
        return {"ok": False, "error": f"unknown tunnel type '{kind}'"}

    fifo_path = os.path.join(RUN_DIR, f"stdin-{tunnel_id}.fifo")
    pid = _spawn_detached(cmd, log_path, stdin_data=stdin_data, fifo_path=fifo_path)

    if kind == "openconnect":
        # No --background is used, so `pid` IS the real, long-lived
        # openconnect process. Give it a few seconds to complete the TLS
        # handshake, certificate prompt, and login before checking it is
        # still alive (a quick failure means auth/cert/network problem).
        alive = True
        for _ in range(16):  # up to ~8s
            time.sleep(0.5)
            if not _pid_alive(pid):
                alive = False
                break
    else:
        time.sleep(0.5)
        alive = _pid_alive(pid)

    state = load_state()
    state["tunnels"][tunnel_id] = {
        "namespace": name, "type": kind, "pid": pid,
        "log": log_path, "fifo": fifo_path, "started": time.time(),
        "meta": {k: v for k, v in args.items() if k != "password"},
    }
    save_state(state)

    if not alive:
        tail = ""
        try:
            with open(log_path, "r", errors="ignore") as f:
                tail = f.read()[-1500:]
        except Exception:
            pass
        return {"ok": False, "tunnel_id": tunnel_id, "pid": pid, "log": log_path,
                "error": f"Tunnel process exited before establishing connection. Log tail:\n{tail}"}

    return {"ok": alive, "tunnel_id": tunnel_id, "pid": pid, "log": log_path}


def stop_tunnel(args):
    tunnel_id = args["tunnel_id"]
    state = load_state()
    t = state["tunnels"].get(tunnel_id)
    if not t:
        return {"ok": False, "error": "tunnel not found"}
    _kill_pid(t.get("pid"))
    subprocess.run(["pkill", "-9", "-f", tunnel_id], check=False)
    fifo = t.get("fifo")
    if fifo and os.path.exists(fifo):
        os.remove(fifo)
    state["tunnels"].pop(tunnel_id, None)
    save_state(state)
    return {"ok": True}


def send_tunnel_input(args):
    """Write a line of text (e.g. 'yes' to accept a certificate prompt, or
    any other interactive answer) into a running tunnel's stdin FIFO."""
    tunnel_id = args["tunnel_id"]
    text = args.get("text", "")
    state = load_state()
    t = state["tunnels"].get(tunnel_id)
    if not t:
        return {"ok": False, "error": "tunnel not found"}
    fifo = t.get("fifo")
    if not fifo or not os.path.exists(fifo):
        return {"ok": False, "error": "no interactive input channel available for this tunnel"}
    try:
        fd = os.open(fifo, os.O_WRONLY | os.O_NONBLOCK)
        os.write(fd, (text + "\n").encode())
        os.close(fd)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _pid_alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Port bridges (socat: host_port -> namespace:target_port)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Built-in SOCKS5 proxy server (no external dependency needed: microsocks/
# dante are not guaranteed to be packaged everywhere). This tiny, pure
# stdlib SOCKS5 server is launched *inside* the target namespace via
# `ip netns exec <ns> python3 -c <this code> <port>`, so it inherits that
# namespace's routing table/VPN tunnel. Any app on the HOST that then points
# its SOCKS5 settings at 127.0.0.1:<bridged-host-port> (see add_bridge)
# transparently uses the VPN's internet connection.
# ---------------------------------------------------------------------------
_SOCKS5_SERVER_SRC = r'''
import socket, threading, struct, sys, select

def relay(a, b):
    try:
        while True:
            r, _, _ = select.select([a, b], [], [], 60)
            if not r:
                break
            for s in r:
                data = s.recv(8192)
                if not data:
                    return
                (b if s is a else a).sendall(data)
    except Exception:
        pass
    finally:
        for s in (a, b):
            try:
                s.close()
            except Exception:
                pass

def recv_exact(conn, n):
    """conn.recv(n) is NOT guaranteed to return all n bytes in one call --
    it commonly does on a raw local loopback socket, but once traffic is
    relayed through extra hops (socat EXEC, ip netns exec, pipes) reads can
    arrive fragmented. Reading in a loop until exactly n bytes (or a clean
    disconnect) avoids silently corrupting the handshake, which previously
    surfaced as 'client apps just can't connect' while direct-in-namespace
    curl tests (which never touch this code) kept working fine."""
    buf = b""
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("peer closed during handshake")
        buf += chunk
    return buf

def handle(conn):
    try:
        header = recv_exact(conn, 2)
        nmethods = header[1]
        recv_exact(conn, nmethods)
        conn.sendall(b"\x05\x00")  # no-auth accepted
        data = recv_exact(conn, 4)
        ver, cmd, _, atyp = data
        if atyp == 1:
            addr = socket.inet_ntoa(recv_exact(conn, 4))
        elif atyp == 3:
            length = recv_exact(conn, 1)[0]
            addr = recv_exact(conn, length).decode()
        elif atyp == 4:
            addr = socket.inet_ntop(socket.AF_INET6, recv_exact(conn, 16))
        else:
            conn.close()
            return
        port = struct.unpack(">H", recv_exact(conn, 2))[0]
        if cmd != 1:  # only CONNECT supported
            conn.sendall(b"\x05\x07\x00\x01\x00\x00\x00\x00\x00\x00")
            conn.close()
            return
        try:
            remote = socket.create_connection((addr, port), timeout=10)
            bind_addr = remote.getsockname()
            reply = b"\x05\x00\x00\x01" + socket.inet_aton(bind_addr[0]) + struct.pack(">H", bind_addr[1])
            conn.sendall(reply)
        except Exception:
            conn.sendall(b"\x05\x05\x00\x01\x00\x00\x00\x00\x00\x00")
            conn.close()
            return
        t = threading.Thread(target=relay, args=(conn, remote), daemon=True)
        t.start()
        relay(remote, conn)
    except Exception:
        try:
            conn.close()
        except Exception:
            pass

def main():
    port = int(sys.argv[1])
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(128)
    print(f"SOCKS5 proxy listening on 127.0.0.1:{port}", flush=True)
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=handle, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    main()
'''


def start_proxy(args):
    """Start the built-in SOCKS5 proxy server inside a namespace, bound to
    127.0.0.1:<port> within that namespace's network context (so it uses
    whatever VPN/tunnel is active there). Use add_bridge afterwards to
    expose that port to the host."""
    name = args["namespace"]
    port = int(args.get("port", 1080))
    if not ns_exists(name):
        return {"ok": False, "error": f"namespace '{name}' does not exist"}

    proxy_id = f"{name}-proxy-{port}"
    log_path = os.path.join(LOG_DIR, f"proxy-{proxy_id}.log")
    open(log_path, "a").close()
    os.chmod(log_path, 0o666)

    python_bin = sys.executable if os.path.exists(sys.executable) else "python3"
    cmd = ["ip", "netns", "exec", name, python_bin, "-c", _SOCKS5_SERVER_SRC, str(port)]
    pid = _spawn_detached(cmd, log_path)
    time.sleep(0.4)
    alive = _pid_alive(pid)

    if not alive:
        tail = ""
        try:
            with open(log_path, "r", errors="ignore") as f:
                tail = f.read()[-1000:]
        except Exception:
            pass
        return {"ok": False, "error": f"Proxy server failed to start. Log:\n{tail}"}

    state = load_state()
    state.setdefault("proxies", {})[proxy_id] = {
        "namespace": name, "port": port, "pid": pid,
        "log": log_path, "started": time.time(),
    }
    save_state(state)
    return {"ok": True, "proxy_id": proxy_id, "pid": pid, "port": port}


def stop_proxy(args):
    proxy_id = args["proxy_id"]
    state = load_state()
    p = state.get("proxies", {}).get(proxy_id)
    if not p:
        return {"ok": False, "error": "proxy not found"}
    _kill_pid(p.get("pid"))
    state["proxies"].pop(proxy_id, None)
    save_state(state)
    return {"ok": True}

def add_bridge(args):
    name = args["namespace"]
    target_port = args["target_port"]
    host_port = args["host_port"]
    bridge_id = f"{name}-{host_port}-{target_port}"

    socat_path = shutil.which("socat")
    if not socat_path:
        return {"ok": False, "error": "socat not found on host"}

    log_path = os.path.join(LOG_DIR, f"bridge-{bridge_id}.log")
    open(log_path, "a").close()
    os.chmod(log_path, 0o666)

    # دستور داخلی که داخل namespace اجرا می‌شود
    inner_cmd = f"ip netns exec {name} {socat_path} STDIO TCP:127.0.0.1:{target_port}"
    # نقل‌قول‌گذاری کامل دستور تا socat آن را یک پارامتر ببیند
    quoted_cmd = shlex.quote(inner_cmd)
    # استفاده از EXEC با دستور نقل‌قول‌گذاری شده
    cmd = ["socat", f"TCP-LISTEN:{host_port},fork,reuseaddr", f"EXEC:{quoted_cmd}"]
    pid = _spawn_detached(cmd, log_path)
    time.sleep(0.5)
    alive = _pid_alive(pid)

    state = load_state()
    state["bridges"][bridge_id] = {
        "namespace": name, "host_port": host_port, "target_port": target_port,
        "pid": pid, "started": time.time(),
    }
    save_state(state)
    return {"ok": alive, "bridge_id": bridge_id, "pid": pid}

def remove_bridge(args):
    bridge_id = args["bridge_id"]
    state = load_state()
    b = state["bridges"].get(bridge_id)
    if not b:
        return {"ok": False, "error": "bridge not found"}
    _kill_pid(b.get("pid"))
    state["bridges"].pop(bridge_id, None)
    save_state(state)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Diagnostics: IP test, DNS/IP leak test, run arbitrary app in namespace
# ---------------------------------------------------------------------------

def ping_test(args):
    """Ping a fixed, reliable target (default 8.8.8.8) from inside the
    namespace to verify basic network/route reachability, independent of
    DNS or HTTPS/TLS (useful to isolate whether a failure is DNS/HTTP-layer
    or a more fundamental routing/namespace problem)."""
    name = args["namespace"]
    target = args.get("target", "8.8.8.8")
    if not ns_exists(name):
        return {"ok": False, "error": f"namespace '{name}' does not exist"}
    try:
        out = subprocess.run(
            ["ip", "netns", "exec", name, "ping", "-c", "4", "-W", "3", target],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"Ping to {target} timed out (no route / VPN down)."}
    except Exception as e:
        return {"ok": False, "error": str(e)}

    output = out.stdout.strip() or out.stderr.strip()
    if out.returncode == 0 and "0% packet loss" in output:
        return {"ok": True, "result": output}
    if out.returncode == 0:
        return {"ok": True, "result": output}  # some packet loss but still reachable
    return {"ok": False, "error": f"Ping to {target} failed (namespace has no working "
                                   f"route/VPN). Details:\n{output}"}


def test_ip(args):
    name = args["namespace"]
    if not ns_exists(name):
        return {"ok": False, "error": f"namespace '{name}' does not exist"}

    # Multiple well-known "what is my IP" endpoints, all queried with a
    # normal browser User-Agent (several of these WAFs reject bare curl
    # requests with 403 Forbidden otherwise). We try each until one gives a
    # plain, valid IP address, so a single provider having an outage or
    # anti-bot rule does not break the whole feature.
    endpoints = [
        "https://checkip.amazonaws.com",
        "https://ipinfo.io/ip",
        "https://api.ipify.org",
        "https://icanhazip.com",
        "https://ident.me",
    ]
    ua = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
    last_err = None
    for url in endpoints:
        cmd = ["ip", "netns", "exec", name, "curl", "-s", "-S", "--max-time", "8",
               "-A", ua, url]
        try:
            out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, timeout=10)
        except subprocess.TimeoutExpired:
            last_err = f"Timed out reaching {url}"
            continue
        except Exception as e:
            last_err = str(e)
            continue

        raw = out.stdout.strip()
        # A valid IPv4/IPv6 response is short and has no HTML/error markup.
        if raw and "<html" not in raw.lower() and "<!doctype" not in raw.lower() and len(raw) < 64:
            return {"ok": True, "ip": raw}

        err = out.stderr.strip() or (raw[:150] if raw else f"curl exited with code {out.returncode}")
        last_err = f"{url} -> {err}"

    return {"ok": False, "error": ("No valid response from any IP-check service. "
                                    "This usually means the namespace has no working "
                                    f"VPN/internet connection. Last error: {last_err}")}


def leak_test(args):
    name = args["namespace"]
    if not ns_exists(name):
        return {"ok": False, "error": "namespace not found"}
    result = {}
    try:
        ip_out = subprocess.run(["ip", "netns", "exec", name, "curl", "-s", "--max-time", "8",
                                  "https://ipapi.co/json/"], stdout=subprocess.PIPE, text=True, timeout=10)
        result["ip_info"] = ip_out.stdout.strip()
    except Exception as e:
        result["ip_info_error"] = str(e)
    try:
        dns_out = subprocess.run(["ip", "netns", "exec", name, "curl", "-s", "--max-time", "8",
                                   "https://www.dnsleaktest.com/api/v1/servers"],
                                  stdout=subprocess.PIPE, text=True, timeout=10)
        result["dns_probe"] = dns_out.stdout.strip()
    except Exception as e:
        result["dns_probe_error"] = str(e)
    return {"ok": True, "result": result}


def launch_app(args):
    name = args["namespace"]
    command = args["command"]
    run_as_user = args.get("run_as_user")
    if not ns_exists(name):
        return {"ok": False, "error": "namespace not found"}
    cmd = ["ip", "netns", "exec", name]
    if run_as_user:
        home = real_user_home(run_as_user)
        cmd += ["runuser", "-u", run_as_user, "--", "env", f"HOME={home}", f"DISPLAY={os.environ.get('DISPLAY', ':0')}"]
    cmd += command
    log_path = os.path.join(LOG_DIR, f"app-{name}-{int(time.time())}.log")
    open(log_path, "a").close()
    os.chmod(log_path, 0o666)
    pid = _spawn_detached(cmd, log_path)
    return {"ok": _pid_alive(pid), "pid": pid, "log": log_path}


# ---------------------------------------------------------------------------
# Dependency check / install (pacman, Arch Linux)
# ---------------------------------------------------------------------------

REQUIRED_PKGS = {
    "socat": "socat", "openconnect": "openconnect",
    "openfortivpn": "openfortivpn", "openvpn": "openvpn",
    "ip": "iproute2", "iptables": "iptables",
}


def check_deps(args=None):
    status = {bin_: (shutil.which(bin_) is not None) for bin_ in REQUIRED_PKGS}
    return {"ok": True, "status": status}


def install_deps(args):
    missing_pkgs = [REQUIRED_PKGS[b] for b in args.get("bins", []) if b in REQUIRED_PKGS]
    if not missing_pkgs:
        return {"ok": True, "installed": []}
    cmd = ["pacman", "-S", "--noconfirm", "--needed"] + missing_pkgs
    res = run(cmd, check=False, capture=True)
    return {"ok": res.returncode == 0, "output": res.stdout, "installed": missing_pkgs}


# ---------------------------------------------------------------------------
ACTIONS = {
    "create_namespace": create_namespace,
    "delete_namespace": delete_namespace,
    "list_namespaces": list_namespaces,
    "start_tunnel": start_tunnel,
    "stop_tunnel": stop_tunnel,
    "send_tunnel_input": send_tunnel_input,
    "ping_test": ping_test,
    "add_bridge": add_bridge,
    "remove_bridge": remove_bridge,
    "start_proxy": start_proxy,
    "stop_proxy": stop_proxy,
    "test_ip": test_ip,
    "leak_test": leak_test,
    "launch_app": launch_app,
    "check_deps": check_deps,
    "install_deps": install_deps,
}


def main():
    if os.geteuid() != 0:
        print(json.dumps({"ok": False, "error": "netgui-helper must run as root (invoke via pkexec)"}))
        sys.exit(1)
    ensure_dirs()
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "no command supplied"}))
        sys.exit(1)
    try:
        payload = json.loads(sys.argv[1])
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"invalid JSON: {e}"}))
        sys.exit(1)

    action = payload.get("action")
    args = payload.get("args", {})
    func = ACTIONS.get(action)
    if not func:
        print(json.dumps({"ok": False, "error": f"unknown action '{action}'"}))
        sys.exit(1)

    try:
        result = func(args)
    except subprocess.CalledProcessError as e:
        result = {"ok": False, "error": f"command failed: {e}"}
    except Exception as e:
        result = {"ok": False, "error": str(e)}

    print(json.dumps(result))


if __name__ == "__main__":
    main()
