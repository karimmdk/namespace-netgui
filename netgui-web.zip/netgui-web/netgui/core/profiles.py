"""
Local (unprivileged) VPN profile storage: saved configs for FortiClient,
OpenConnect, Psiphon, Nekoray, plus import/export to a single JSON file.
Stored under the user's own config dir (no root needed) since profiles
contain only paths/servers/usernames -- never plaintext passwords by default.
"""
import json
import os
from pathlib import Path

CONFIG_DIR = Path(os.path.expanduser("~/.config/netgui"))
PROFILES_FILE = CONFIG_DIR / "profiles.json"


def _ensure():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not PROFILES_FILE.exists():
        PROFILES_FILE.write_text(json.dumps({"profiles": []}, indent=2))


def load_profiles() -> list[dict]:
    _ensure()
    try:
        return json.loads(PROFILES_FILE.read_text()).get("profiles", [])
    except Exception:
        return []


def save_profiles(profiles: list[dict]):
    _ensure()
    PROFILES_FILE.write_text(json.dumps({"profiles": profiles}, indent=2))


def add_profile(profile: dict):
    profiles = load_profiles()
    profiles = [p for p in profiles if p.get("name") != profile.get("name")]
    profiles.append(profile)
    save_profiles(profiles)


def delete_profile(name: str):
    profiles = [p for p in load_profiles() if p.get("name") != name]
    save_profiles(profiles)


def export_profiles(dest_path: str):
    Path(dest_path).write_text(json.dumps({"profiles": load_profiles()}, indent=2))


def import_profiles(src_path: str, merge: bool = True):
    data = json.loads(Path(src_path).read_text())
    incoming = data.get("profiles", [])
    if merge:
        existing = {p["name"]: p for p in load_profiles()}
        for p in incoming:
            existing[p["name"]] = p
        save_profiles(list(existing.values()))
    else:
        save_profiles(incoming)
