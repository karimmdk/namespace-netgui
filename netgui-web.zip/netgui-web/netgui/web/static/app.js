/* NetGUI Web frontend -- vanilla JS, no build step. */

const API = "/api";
let state = { namespaces: {}, tunnels: {}, bridges: {}, proxies: {} };
let logOffsets = {};
let currentLogId = null;
let promptOpen = false;

const PROMPT_PATTERNS = [
  ["Enter 'yes' to accept, 'no' to abort", "yes"],
  ["Continue connecting", "yes"],
  ["Accept?", "yes"],
];

// ------------------------------------------------------------------ utils

function $(sel, root = document) { return root.querySelector(sel); }
function $all(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

function toast(message, type = "info") {
  const stack = $("#toastStack");
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 5000);
}

async function api(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(API + path, opts);
  let data;
  try { data = await res.json(); } catch { data = { ok: false, error: `HTTP ${res.status}` }; }
  if (!res.ok || data.ok === false) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

function fillSelect(select, names, keepCurrent = true) {
  const current = select.value;
  select.innerHTML = "";
  if (select.id === "nsParent") {
    const opt = document.createElement("option");
    opt.value = ""; opt.textContent = "(none — attach to host)";
    select.appendChild(opt);
  }
  names.forEach(name => {
    const opt = document.createElement("option");
    opt.value = name; opt.textContent = name;
    select.appendChild(opt);
  });
  if (keepCurrent && names.includes(current)) select.value = current;
}

// -------------------------------------------------------------- tab logic

function initTabs() {
  $all(".nav-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      $all(".nav-btn").forEach(b => b.classList.remove("active"));
      $all(".panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      $(`.panel[data-panel="${btn.dataset.tab}"]`).classList.add("active");
    });
  });
}

// --------------------------------------------------------------- polling

async function refreshState() {
  try {
    const data = await api("GET", "/state");
    state = data;
    renderNamespaces();
    renderRouteBar();
    renderProxies();
    renderBridges();
    renderSelects();
    renderLogSelect();
  } catch (e) {
    // silent -- keep last good state, network hiccups shouldn't spam toasts
  }
}

function startPolling() {
  refreshState();
  setInterval(refreshState, 2500);
}

// ------------------------------------------------------------- route bar

function renderRouteBar() {
  const root = $("#routeBarInner");
  const names = Object.keys(state.namespaces || {});
  if (names.length === 0) {
    root.innerHTML = `<span class="route-empty">No active namespaces — build a chain to see the live signal path.</span>`;
    return;
  }
  // order by parent linkage: find roots (parent null / not in set) then chain
  const byParent = {};
  names.forEach(n => {
    const p = state.namespaces[n].parent || "";
    (byParent[p] = byParent[p] || []).push(n);
  });
  const ordered = [];
  const visit = (p) => {
    (byParent[p] || []).forEach(n => { ordered.push(n); visit(n); });
  };
  visit("");
  names.forEach(n => { if (!ordered.includes(n)) ordered.push(n); });

  const hasTunnel = (ns) => Object.values(state.tunnels || {}).some(t => t.namespace === ns);

  let html = `<div class="route-node is-live"><span class="pulse"></span>HOST</div>`;
  ordered.forEach(n => {
    const live = hasTunnel(n);
    html += `<div class="route-wire ${live ? "is-live" : ""}"></div>`;
    html += `<div class="route-node ${live ? "is-live" : ""}"><span class="pulse"></span>${n}</div>`;
  });
  const anyLive = ordered.some(hasTunnel);
  html += `<div class="route-wire ${anyLive ? "is-live" : ""}"></div>`;
  html += `<div class="route-node ${anyLive ? "is-live" : ""}"><span class="pulse"></span>APP</div>`;
  root.innerHTML = html;
}

// ------------------------------------------------------------- namespaces

function renderNamespaces() {
  const tbody = $("#nsTable tbody");
  const names = Object.keys(state.namespaces || {});
  tbody.innerHTML = "";
  $("#nsEmptyHint").style.display = names.length ? "none" : "block";
  names.forEach(name => {
    const meta = state.namespaces[name];
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${name}</td>
      <td>${meta.parent || "(host)"}</td>
      <td>${meta.ns_ip || ""}</td>
      <td class="pub-ip">—</td>
      <td></td>`;
    const actions = document.createElement("td");
    const testBtn = document.createElement("button");
    testBtn.className = "btn"; testBtn.textContent = "Test IP";
    testBtn.onclick = async () => {
      tr.querySelector(".pub-ip").textContent = "testing…";
      try {
        const r = await api("GET", `/diagnostics/ip?namespace=${encodeURIComponent(name)}`);
        tr.querySelector(".pub-ip").textContent = r.ip;
      } catch (e) {
        tr.querySelector(".pub-ip").textContent = "error";
        toast(e.message, "error");
      }
    };
    const delBtn = document.createElement("button");
    delBtn.className = "btn btn-danger"; delBtn.textContent = "Delete";
    delBtn.style.marginLeft = "6px";
    delBtn.onclick = async () => {
      if (!confirm(`Delete namespace '${name}' and all its children/tunnels/bridges?`)) return;
      try {
        await api("DELETE", `/namespaces/${encodeURIComponent(name)}`);
        toast(`Deleted ${name}`, "success");
        refreshState();
      } catch (e) { toast(e.message, "error"); }
    };
    actions.appendChild(testBtn);
    actions.appendChild(delBtn);
    tr.lastElementChild.replaceWith(actions);
    tbody.appendChild(tr);
  });
}

function initNamespaceForm() {
  $("#btnCreateNs").addEventListener("click", async () => {
    const name = $("#nsName").value.trim();
    if (!name) { toast("Enter a namespace name.", "error"); return; }
    const dns = $("#nsDns").value.split(",").map(s => s.trim()).filter(Boolean);
    try {
      await api("POST", "/namespaces", {
        name,
        parent: $("#nsParent").value || null,
        host_ip: $("#nsHostIp").value.trim(),
        ns_ip: $("#nsIp").value.trim(),
        dns,
      });
      toast(`Namespace '${name}' created.`, "success");
      $("#nsName").value = "";
      refreshState();
    } catch (e) { toast(e.message, "error"); }
  });
}

// ------------------------------------------------------------ all selects

function renderSelects() {
  const names = Object.keys(state.namespaces || {});
  fillSelect($("#nsParent"), names);
  fillSelect($("#proxyNs"), names);
  fillSelect($("#bridgeNs"), names);
  fillSelect($("#diagNs"), names);
  fillSelect($("#launchNs"), names);
}

// ------------------------------------------------------------ chain wizard

const HOP_FIELD_MAP = {
  forticlient: ["config_path", "extra_args"],
  openconnect: ["server", "username", "password", "insecure", "extra_args"],
  openvpn: ["config_path", "username", "password", "extra_args"],
  psiphon: ["binary_path", "socks_port", "region", "extra_args"],
  nekoray: ["binary_path", "socks_port", "extra_args"],
};

function hopFieldsHtml(idx) {
  return `
  <div class="hop-card" data-hop="${idx}">
    <h3>Hop ${idx + 1}</h3>
    <div class="form-grid">
      <label>Type
        <select class="hop-type">
          <option value="forticlient">forticlient</option>
          <option value="openconnect">openconnect</option>
          <option value="openvpn">openvpn</option>
          <option value="psiphon">psiphon</option>
          <option value="nekoray">nekoray</option>
        </select>
      </label>
      <label>Saved profile
        <select class="hop-profile"><option value="">(none)</option></select>
      </label>
      <label class="field-config_path">Config path
        <input type="text" class="hop-config_path" placeholder="~/vpn.config" />
      </label>
      <label class="field-server">Server
        <input type="text" class="hop-server" placeholder="https://host:port" />
      </label>
      <label class="field-username">Username
        <input type="text" class="hop-username" />
      </label>
      <label class="field-password">Password
        <input type="password" class="hop-password" />
      </label>
      <label class="field-insecure checkbox-row">
        <input type="checkbox" class="hop-insecure" checked /> Accept expired/self-signed certificate
      </label>
      <label class="field-binary_path">Binary path
        <input type="text" class="hop-binary_path" placeholder="~/opt/nekoray/nekoray.AppImage" />
      </label>
      <label class="field-socks_port">SOCKS port
        <input type="number" class="hop-socks_port" value="1081" />
      </label>
      <label class="field-region">Region
        <input type="text" class="hop-region" value="any" />
      </label>
      <label class="field-extra_args span-2">Extra arguments
        <input type="text" class="hop-extra_args" placeholder="--servercert pin-sha256:..." />
      </label>
    </div>
  </div>`;
}

function applyHopVisibility(hopEl) {
  const kind = $(".hop-type", hopEl).value;
  const visible = new Set(HOP_FIELD_MAP[kind] || []);
  ["config_path", "server", "username", "password", "insecure", "binary_path", "socks_port", "region", "extra_args"]
    .forEach(f => {
      const label = hopEl.querySelector(`.field-${f}`);
      if (label) label.style.display = visible.has(f) ? "" : "none";
    });
}

async function refreshHopProfiles(hopEl) {
  const kind = $(".hop-type", hopEl).value;
  const profSelect = $(".hop-profile", hopEl);
  try {
    const { profiles } = await api("GET", "/profiles");
    profSelect.innerHTML = `<option value="">(none)</option>`;
    profiles.filter(p => p.type === kind).forEach(p => {
      const opt = document.createElement("option");
      opt.value = p.name; opt.textContent = p.name;
      opt.dataset.profile = JSON.stringify(p);
      profSelect.appendChild(opt);
    });
  } catch (e) { /* ignore */ }
}

function rebuildHops(count) {
  const container = $("#hopsContainer");
  container.innerHTML = "";
  for (let i = 0; i < count; i++) {
    container.insertAdjacentHTML("beforeend", hopFieldsHtml(i));
    const hopEl = container.lastElementChild;
    applyHopVisibility(hopEl);
    refreshHopProfiles(hopEl);
    $(".hop-type", hopEl).addEventListener("change", () => {
      applyHopVisibility(hopEl);
      refreshHopProfiles(hopEl);
    });
    $(".hop-profile", hopEl).addEventListener("change", (e) => {
      const opt = e.target.selectedOptions[0];
      if (!opt || !opt.dataset.profile) return;
      const p = JSON.parse(opt.dataset.profile);
      if (hopEl.querySelector(".hop-config_path")) hopEl.querySelector(".hop-config_path").value = p.config_path || "";
      if (hopEl.querySelector(".hop-server")) hopEl.querySelector(".hop-server").value = p.server || "";
      if (hopEl.querySelector(".hop-username")) hopEl.querySelector(".hop-username").value = p.username || "";
      if (hopEl.querySelector(".hop-binary_path")) hopEl.querySelector(".hop-binary_path").value = p.binary_path || "";
      if (p.region && hopEl.querySelector(".hop-region")) hopEl.querySelector(".hop-region").value = p.region;
    });
  }
}

function hopToArgs(hopEl) {
  const kind = $(".hop-type", hopEl).value;
  const args = { type: kind };
  const val = (cls) => { const el = hopEl.querySelector(`.${cls}`); return el ? el.value.trim() : ""; };
  if (kind === "forticlient") {
    args.config_path = val("hop-config_path");
  } else if (kind === "openconnect") {
    args.server = val("hop-server");
    args.username = val("hop-username");
    args.password = hopEl.querySelector(".hop-password").value;
    args.insecure = hopEl.querySelector(".hop-insecure").checked;
  } else if (kind === "openvpn") {
    args.config_path = val("hop-config_path");
    args.username = val("hop-username") || null;
    args.password = hopEl.querySelector(".hop-password").value || null;
  } else if (kind === "psiphon") {
    args.binary_path = val("hop-binary_path") || null;
    args.socks_port = parseInt(val("hop-socks_port") || "1081", 10);
    args.region = val("hop-region") || "any";
  } else if (kind === "nekoray") {
    args.binary_path = val("hop-binary_path");
    args.socks_port = parseInt(val("hop-socks_port") || "1081", 10);
  }
  args.extra_args = val("hop-extra_args");
  return args;
}

let presets = [];

async function initChainWizard() {
  $("#hopCount").addEventListener("change", (e) => {
    rebuildHops(Math.max(1, Math.min(6, parseInt(e.target.value, 10) || 1)));
  });
  rebuildHops(1);

  try {
    const { presets: p } = await api("GET", "/presets");
    presets = p;
    const sel = $("#presetSelect");
    sel.innerHTML = "";
    presets.forEach(p => {
      const opt = document.createElement("option");
      opt.value = p.id; opt.textContent = p.label;
      sel.appendChild(opt);
    });
  } catch (e) { /* ignore */ }

  $("#btnApplyPreset").addEventListener("click", () => {
    const preset = presets.find(p => p.id === $("#presetSelect").value);
    if (!preset) return;
    $("#hopCount").value = preset.chain.length;
    rebuildHops(preset.chain.length);
    preset.chain.forEach((hop, i) => {
      const hopEl = $all(".hop-card")[i];
      $(".hop-type", hopEl).value = hop.type;
      applyHopVisibility(hopEl);
      refreshHopProfiles(hopEl);
    });
  });

  let chainNames = [];

  $("#btnRunChain").addEventListener("click", async () => {
    const hopEls = $all(".hop-card");
    chainNames = hopEls.map((_, i) => `chain-${i + 1}`);
    const statusEl = $("#chainStatus");
    try {
      for (let i = 0; i < chainNames.length; i++) {
        statusEl.textContent = `Creating namespace ${chainNames[i]} (${i + 1}/${chainNames.length})...`;
        const subnet = 200 + i;
        await api("POST", "/namespaces", {
          name: chainNames[i],
          parent: i > 0 ? chainNames[i - 1] : null,
          host_ip: `10.${subnet}.0.1`,
          ns_ip: `10.${subnet}.0.2`,
          dns: ["1.1.1.1", "8.8.8.8"],
        });
      }
      statusEl.textContent = "All namespaces created. Launching tunnels...";
      for (let i = 0; i < hopEls.length; i++) {
        const args = hopToArgs(hopEls[i]);
        args.namespace = chainNames[i];
        args.id = `${chainNames[i]}-tunnel`;
        statusEl.textContent = `Starting tunnel in ${chainNames[i]}...`;
        await api("POST", "/tunnels", args);
      }
      statusEl.textContent = "Chain fully connected.";
      toast("Chain connected.", "success");
      refreshState();
    } catch (e) {
      statusEl.textContent = `Error: ${e.message}`;
      toast(e.message, "error");
    }
  });

  $("#btnTeardownChain").addEventListener("click", async () => {
    if (!chainNames.length) { toast("No chain to tear down.", "error"); return; }
    try {
      await api("DELETE", `/namespaces/${encodeURIComponent(chainNames[0])}`);
      $("#chainStatus").textContent = "Chain torn down.";
      toast("Chain torn down.", "success");
      chainNames = [];
      refreshState();
    } catch (e) { toast(e.message, "error"); }
  });
}

// ----------------------------------------------------------------- proxy

function renderProxies() {
  const tbody = $("#proxyTable tbody");
  const proxies = state.proxies || {};
  const bridges = state.bridges || {};
  const ids = Object.keys(proxies);
  tbody.innerHTML = "";
  $("#proxyEmptyHint").style.display = ids.length ? "none" : "block";
  ids.forEach(proxyId => {
    const meta = proxies[proxyId];
    const match = Object.entries(bridges).find(([, b]) => b.namespace === meta.namespace && b.target_port === meta.port);
    const hostPort = match ? match[1].host_port : null;
    const bridgeId = match ? match[0] : null;
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${meta.namespace}</td>
      <td>${meta.port}</td>
      <td>${hostPort ?? "(not bridged)"}</td>
      <td>${hostPort ? `127.0.0.1:${hostPort}` : "-"}</td>
      <td></td>`;
    const stopBtn = document.createElement("button");
    stopBtn.className = "btn btn-danger"; stopBtn.textContent = "Stop";
    stopBtn.onclick = async () => {
      try {
        await api("DELETE", `/proxy/${encodeURIComponent(proxyId)}`);
        if (bridgeId) await api("DELETE", `/bridges/${encodeURIComponent(bridgeId)}`);
        toast("Proxy stopped.", "success");
        refreshState();
      } catch (e) { toast(e.message, "error"); }
    };
    tr.lastElementChild.appendChild(stopBtn);
    tbody.appendChild(tr);
  });
}

function initProxyForm() {
  $("#btnStartProxy").addEventListener("click", async () => {
    const ns = $("#proxyNs").value;
    if (!ns) { toast("Create a namespace first.", "error"); return; }
    const port = parseInt($("#proxyPort").value, 10);
    const hostPort = parseInt($("#proxyHostPort").value, 10);
    const alsoBridge = $("#proxyAlsoBridge").checked;
    try {
      await api("POST", "/proxy", { namespace: ns, port });
      if (alsoBridge) {
        try {
          await api("POST", "/bridges", { namespace: ns, target_port: port, host_port: hostPort });
          toast(`Proxy ready — use 127.0.0.1:${hostPort} as your SOCKS5 address.`, "success");
        } catch (e) {
          toast(`Proxy started inside the namespace, but bridging to host failed: ${e.message}`, "error");
        }
      } else {
        toast(`Proxy started inside '${ns}' on port ${port} (not exposed to host).`, "success");
      }
      refreshState();
    } catch (e) { toast(e.message, "error"); }
  });
}

// --------------------------------------------------------------- bridges

function renderBridges() {
  const tbody = $("#bridgeTable tbody");
  const bridges = state.bridges || {};
  const ids = Object.keys(bridges);
  tbody.innerHTML = "";
  $("#bridgeEmptyHint").style.display = ids.length ? "none" : "block";
  ids.forEach(bridgeId => {
    const meta = bridges[bridgeId];
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${meta.namespace}</td><td>${meta.host_port}</td><td>${meta.target_port}</td><td></td>`;
    const btn = document.createElement("button");
    btn.className = "btn btn-danger"; btn.textContent = "Remove";
    btn.onclick = async () => {
      try {
        await api("DELETE", `/bridges/${encodeURIComponent(bridgeId)}`);
        toast("Bridge removed.", "success");
        refreshState();
      } catch (e) { toast(e.message, "error"); }
    };
    tr.lastElementChild.appendChild(btn);
    tbody.appendChild(tr);
  });
}

function initBridgeForm() {
  $("#btnAddBridge").addEventListener("click", async () => {
    const ns = $("#bridgeNs").value;
    if (!ns) { toast("Create a namespace first.", "error"); return; }
    try {
      await api("POST", "/bridges", {
        namespace: ns,
        target_port: parseInt($("#bridgeTargetPort").value, 10),
        host_port: parseInt($("#bridgeHostPort").value, 10),
      });
      toast("Bridge added.", "success");
      refreshState();
    } catch (e) { toast(e.message, "error"); }
  });
}

// -------------------------------------------------------------- profiles

async function reloadProfiles() {
  try {
    const { profiles } = await api("GET", "/profiles");
    const list = $("#profileList");
    list.innerHTML = "";
    if (!profiles.length) {
      list.innerHTML = `<span class="empty-hint">No saved profiles yet.</span>`;
      return;
    }
    profiles.forEach(p => {
      const chip = document.createElement("div");
      chip.className = "chip";
      chip.innerHTML = `${p.name} <span style="color:var(--text-faint)">(${p.type})</span>`;
      const loadBtn = document.createElement("button");
      loadBtn.className = "load-btn"; loadBtn.textContent = "✎";
      loadBtn.title = "Load into the form";
      loadBtn.onclick = () => {
        $("#profName").value = p.name || "";
        $("#profType").value = p.type || "forticlient";
        $("#profConfigPath").value = p.config_path || "";
        $("#profServer").value = p.server || "";
        $("#profUsername").value = p.username || "";
        $("#profRegion").value = p.region || "any";
        $("#profBinaryPath").value = p.binary_path || "";
      };
      const delBtn = document.createElement("button");
      delBtn.textContent = "✕";
      delBtn.onclick = async () => {
        try {
          await api("DELETE", `/profiles/${encodeURIComponent(p.name)}`);
          toast(`Profile '${p.name}' deleted.`, "success");
          reloadProfiles();
        } catch (e) { toast(e.message, "error"); }
      };
      chip.appendChild(loadBtn);
      chip.appendChild(delBtn);
      list.appendChild(chip);
    });
  } catch (e) { /* ignore */ }
}

function initProfilesForm() {
  $("#btnSaveProfile").addEventListener("click", async () => {
    const name = $("#profName").value.trim();
    if (!name) { toast("Enter a profile name.", "error"); return; }
    try {
      await api("POST", "/profiles", {
        name,
        type: $("#profType").value,
        config_path: $("#profConfigPath").value.trim(),
        server: $("#profServer").value.trim(),
        username: $("#profUsername").value.trim(),
        region: $("#profRegion").value.trim() || "any",
        binary_path: $("#profBinaryPath").value.trim(),
      });
      toast(`Profile '${name}' saved.`, "success");
      reloadProfiles();
    } catch (e) { toast(e.message, "error"); }
  });

  $("#btnExportProfiles").addEventListener("click", async () => {
    const { profiles } = await api("GET", "/profiles/export");
    const blob = new Blob([JSON.stringify({ profiles }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "netgui-profiles.json"; a.click();
    URL.revokeObjectURL(url);
  });

  $("#importProfilesFile").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      await api("POST", "/profiles/import", { profiles: data.profiles || [] });
      toast("Profiles imported.", "success");
      reloadProfiles();
    } catch (err) { toast(err.message, "error"); }
    e.target.value = "";
  });
}

// ---------------------------------------------------------- diagnostics

function renderLogSelect() {
  const sel = $("#logSelect");
  const current = sel.value;
  const entries = [];
  Object.entries(state.tunnels || {}).forEach(([id, t]) => entries.push([id, `${id} (${t.type})`]));
  sel.innerHTML = "";
  entries.forEach(([id, label]) => {
    const opt = document.createElement("option");
    opt.value = id; opt.textContent = label;
    sel.appendChild(opt);
  });
  if (entries.some(([id]) => id === current)) sel.value = current;
  if (sel.value !== currentLogId) attachLog(sel.value || null);
}

function attachLog(logId) {
  currentLogId = logId || null;
  logOffsets[currentLogId] = 0;
  $("#logView").textContent = "";
}

async function tailLog() {
  if (!currentLogId) return;
  try {
    const offset = logOffsets[currentLogId] || 0;
    const r = await api("GET", `/logs/${encodeURIComponent(currentLogId)}?offset=${offset}`);
    if (r.chunk) {
      const box = $("#logView");
      const atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 6;
      box.textContent += r.chunk;
      if (atBottom) box.scrollTop = box.scrollHeight;
      checkForPrompt(r.chunk);
    }
    logOffsets[currentLogId] = r.offset;
  } catch (e) { /* log may not exist yet */ }
}

function checkForPrompt(chunk) {
  if (promptOpen || !currentLogId) return;
  for (const [pattern, answer] of PROMPT_PATTERNS) {
    if (chunk.includes(pattern)) {
      promptOpen = true;
      const send = confirm(`The tunnel process is waiting for input:\n\n"${pattern}"\n\nSend "${answer}" to it now?`);
      if (send) sendTunnelInput(currentLogId, answer);
      promptOpen = false;
      break;
    }
  }
}

async function sendTunnelInput(tunnelId, text) {
  try {
    await api("POST", `/tunnels/${encodeURIComponent(tunnelId)}/input`, { text });
    toast(`Sent '${text}' to tunnel.`, "success");
  } catch (e) { toast(`Failed to send input: ${e.message}`, "error"); }
}

function initDiagnostics() {
  $("#logSelect").addEventListener("change", (e) => attachLog(e.target.value));
  setInterval(tailLog, 1000);

  $("#btnClearLog").addEventListener("click", async () => {
    if (!currentLogId) { $("#logView").textContent = ""; return; }
    try {
      await api("POST", `/logs/${encodeURIComponent(currentLogId)}/clear`);
      logOffsets[currentLogId] = 0;
      $("#logView").textContent = "";
    } catch (e) { toast(e.message, "error"); }
  });

  $("#btnSendAnswer").addEventListener("click", () => {
    const text = $("#manualAnswer").value.trim();
    if (!text || !currentLogId) { toast("Select a tunnel log and type an answer first.", "error"); return; }
    sendTunnelInput(currentLogId, text);
    $("#manualAnswer").value = "";
  });

  $("#btnTestIp").addEventListener("click", async () => {
    const ns = $("#diagNs").value;
    if (!ns) { toast("Select a namespace first.", "error"); return; }
    $("#diagResult").textContent = `Testing IP for '${ns}'...`;
    try {
      const r = await api("GET", `/diagnostics/ip?namespace=${encodeURIComponent(ns)}`);
      $("#diagResult").textContent = `Public IP: ${r.ip}`;
    } catch (e) { $("#diagResult").textContent = `ERROR: ${e.message}`; }
  });

  $("#btnPingTest").addEventListener("click", async () => {
    const ns = $("#diagNs").value;
    if (!ns) { toast("Select a namespace first.", "error"); return; }
    $("#diagResult").textContent = `Pinging 8.8.8.8 from '${ns}'...`;
    try {
      const r = await api("GET", `/diagnostics/ping?namespace=${encodeURIComponent(ns)}`);
      $("#diagResult").textContent = r.result;
    } catch (e) { $("#diagResult").textContent = `ERROR: ${e.message}`; }
  });

  $("#btnLeakTest").addEventListener("click", async () => {
    const ns = $("#diagNs").value;
    if (!ns) return;
    $("#diagResult").textContent = "Running leak test...";
    try {
      const r = await api("GET", `/diagnostics/leak?namespace=${encodeURIComponent(ns)}`);
      $("#diagResult").textContent = JSON.stringify(r.result, null, 2);
    } catch (e) { $("#diagResult").textContent = `Error: ${e.message}`; }
  });

  $("#btnLaunch").addEventListener("click", async () => {
    const ns = $("#launchNs").value;
    const cmd = $("#launchCmd").value.trim();
    if (!ns || !cmd) return;
    try {
      const r = await api("POST", "/launch", { namespace: ns, command: cmd.split(/\s+/) });
      $("#diagResult").textContent = `Launched PID ${r.pid}`;
    } catch (e) { $("#diagResult").textContent = `Error: ${e.message}`; }
  });
}

// ---------------------------------------------------------------- settings

function initSettings() {
  $all('input[name="theme"]').forEach(r => {
    r.addEventListener("change", () => {
      document.body.dataset.theme = r.value;
      localStorage.setItem("netgui-theme", r.value);
    });
  });
  const saved = localStorage.getItem("netgui-theme");
  if (saved) {
    document.body.dataset.theme = saved;
    const radio = document.querySelector(`input[name="theme"][value="${saved}"]`);
    if (radio) radio.checked = true;
  }

  $("#btnCheckDeps").addEventListener("click", async () => {
    try {
      const r = await api("GET", "/deps");
      window._lastDeps = r.status;
      const lines = Object.entries(r.status).map(([bin, ok]) => `${ok ? "OK " : "MISSING"}  ${bin}`);
      $("#depsView").textContent = lines.join("\n");
    } catch (e) { $("#depsView").textContent = `Error: ${e.message}`; }
  });

  $("#btnInstallDeps").addEventListener("click", async () => {
    const missing = Object.entries(window._lastDeps || {}).filter(([, ok]) => !ok).map(([b]) => b);
    if (!missing.length) { $("#depsView").textContent += "\nNothing to install (run Check first)."; return; }
    try {
      const r = await api("POST", "/deps/install", { bins: missing });
      $("#depsView").textContent += `\nInstalled: ${r.installed.join(", ")}`;
    } catch (e) { $("#depsView").textContent += `\nError: ${e.message}`; }
  });
}

// -------------------------------------------------------------------- init

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initNamespaceForm();
  initChainWizard();
  initProxyForm();
  initBridgeForm();
  initProfilesForm();
  initDiagnostics();
  initSettings();
  reloadProfiles();
  startPolling();
});
