"""
NetGUI Web -- same privileged backend (netgui/core/helper.py via pkexec) as
the desktop app, exposed as a small local Flask API + a single-page frontend.

Nothing about the privilege model changes: every write action still goes
through bridge_client.call(), which still shells out to
`pkexec python3 <path>/helper.py ...`, so you still get a normal graphical
password prompt the first time each session. This process itself (the Flask
server) never needs to run as root.

Run with: python3 run_web.py
"""
import json
import os
import subprocess
import time

from flask import Flask, jsonify, request, send_from_directory

from netgui.core.bridge_client import call, HelperError
from netgui.core.constants import STATE_FILE
from netgui.core.presets import PRESETS
from netgui.core import profiles as profile_store

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    static_folder=os.path.join(BASE_DIR, "static"),
    template_folder=os.path.join(BASE_DIR, "templates"),
)


def ok(data=None, **extra):
    payload = {"ok": True}
    if data:
        payload.update(data)
    payload.update(extra)
    return jsonify(payload)


def err(message, status=400):
    return jsonify({"ok": False, "error": message}), status


def call_helper(action, args=None):
    """Call the privileged helper and translate its result into a Flask
    response. HelperError (pkexec missing, timeout, malformed output) is
    reported as a 502 so the frontend can distinguish "helper said no" from
    "couldn't even reach the helper"."""
    try:
        result = call(action, args or {})
    except HelperError as e:
        return err(str(e), status=502)
    if not result.get("ok", False):
        return err(result.get("error", "Unknown error"), status=400)
    return jsonify(result)


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(app.template_folder, "index.html")


# ---------------------------------------------------------------------------
# Live state (unprivileged: reads state.json + `ip netns list` directly,
# exactly like the desktop app's PollWorker -- no pkexec needed just to read)
# ---------------------------------------------------------------------------

@app.route("/api/state")
def api_state():
    state = {"namespaces": {}, "tunnels": {}, "bridges": {}, "proxies": {}}
    try:
        out = subprocess.run(["ip", "netns", "list"], stdout=subprocess.PIPE, text=True)
        live = [l.split()[0] for l in out.stdout.splitlines() if l.strip()]
        try:
            with open(STATE_FILE) as f:
                disk_state = json.load(f)
        except Exception:
            disk_state = {}
        for name in live:
            state["namespaces"][name] = disk_state.get("namespaces", {}).get(name, {})
        state["tunnels"] = disk_state.get("tunnels", {})
        state["bridges"] = disk_state.get("bridges", {})
        state["proxies"] = disk_state.get("proxies", {})
    except Exception as e:
        return err(str(e), status=500)
    return ok(state)


@app.route("/api/presets")
def api_presets():
    return ok({"presets": PRESETS})


# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------

@app.route("/api/namespaces", methods=["POST"])
def api_create_namespace():
    body = request.get_json(force=True)
    return call_helper("create_namespace", body)


@app.route("/api/namespaces/<name>", methods=["DELETE"])
def api_delete_namespace(name):
    return call_helper("delete_namespace", {"name": name})


# ---------------------------------------------------------------------------
# Tunnels
# ---------------------------------------------------------------------------

@app.route("/api/tunnels", methods=["POST"])
def api_start_tunnel():
    body = request.get_json(force=True)
    return call_helper("start_tunnel", body)


@app.route("/api/tunnels/<tunnel_id>", methods=["DELETE"])
def api_stop_tunnel(tunnel_id):
    return call_helper("stop_tunnel", {"tunnel_id": tunnel_id})


@app.route("/api/tunnels/<tunnel_id>/input", methods=["POST"])
def api_send_tunnel_input(tunnel_id):
    body = request.get_json(force=True)
    return call_helper("send_tunnel_input", {"tunnel_id": tunnel_id, "text": body.get("text", "")})


# ---------------------------------------------------------------------------
# Proxy (built-in SOCKS5) + Bridges (socat host<->ns port forward)
# ---------------------------------------------------------------------------

@app.route("/api/proxy", methods=["POST"])
def api_start_proxy():
    body = request.get_json(force=True)
    return call_helper("start_proxy", body)


@app.route("/api/proxy/<proxy_id>", methods=["DELETE"])
def api_stop_proxy(proxy_id):
    return call_helper("stop_proxy", {"proxy_id": proxy_id})


@app.route("/api/bridges", methods=["POST"])
def api_add_bridge():
    body = request.get_json(force=True)
    return call_helper("add_bridge", body)


@app.route("/api/bridges/<bridge_id>", methods=["DELETE"])
def api_remove_bridge(bridge_id):
    return call_helper("remove_bridge", {"bridge_id": bridge_id})


# ---------------------------------------------------------------------------
# Profiles (unprivileged: plain user-config JSON file, no pkexec needed)
# ---------------------------------------------------------------------------

@app.route("/api/profiles", methods=["GET"])
def api_list_profiles():
    return ok({"profiles": profile_store.load_profiles()})


@app.route("/api/profiles", methods=["POST"])
def api_save_profile():
    profile = request.get_json(force=True)
    if not profile.get("name"):
        return err("Profile name is required.")
    profile_store.add_profile(profile)
    return ok({"profiles": profile_store.load_profiles()})


@app.route("/api/profiles/<name>", methods=["DELETE"])
def api_delete_profile(name):
    profile_store.delete_profile(name)
    return ok({"profiles": profile_store.load_profiles()})


@app.route("/api/profiles/export")
def api_export_profiles():
    return ok({"profiles": profile_store.load_profiles()})


@app.route("/api/profiles/import", methods=["POST"])
def api_import_profiles():
    body = request.get_json(force=True)
    incoming = body.get("profiles", [])
    existing = {p["name"]: p for p in profile_store.load_profiles()}
    for p in incoming:
        if p.get("name"):
            existing[p["name"]] = p
    profile_store.save_profiles(list(existing.values()))
    return ok({"profiles": profile_store.load_profiles()})


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

@app.route("/api/diagnostics/ip")
def api_test_ip():
    ns = request.args.get("namespace", "")
    return call_helper("test_ip", {"namespace": ns})


@app.route("/api/diagnostics/ping")
def api_ping_test():
    ns = request.args.get("namespace", "")
    target = request.args.get("target", "8.8.8.8")
    return call_helper("ping_test", {"namespace": ns, "target": target})


@app.route("/api/diagnostics/leak")
def api_leak_test():
    ns = request.args.get("namespace", "")
    return call_helper("leak_test", {"namespace": ns})


@app.route("/api/launch", methods=["POST"])
def api_launch_app():
    body = request.get_json(force=True)
    return call_helper("launch_app", body)


@app.route("/api/logs/<path:log_id>")
def api_tail_log(log_id):
    """Tail a log file by tunnel/proxy/bridge id, using the same path
    convention as helper.py. Reading is unprivileged since helper.py writes
    all state/log files as mode 0666."""
    offset = int(request.args.get("offset", 0))
    state = {}
    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
    except Exception:
        pass

    log_path = None
    for bucket in ("tunnels", "proxies", "bridges"):
        entry = state.get(bucket, {}).get(log_id)
        if entry:
            log_path = entry.get("log")
            break
    if not log_path or not os.path.exists(log_path):
        return err("log not found", status=404)

    with open(log_path, "r", errors="ignore") as f:
        f.seek(offset)
        chunk = f.read()
        new_offset = f.tell()
    return ok({"chunk": chunk, "offset": new_offset})


@app.route("/api/logs/<path:log_id>/clear", methods=["POST"])
def api_clear_log(log_id):
    state = {}
    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
    except Exception:
        pass
    log_path = None
    for bucket in ("tunnels", "proxies", "bridges"):
        entry = state.get(bucket, {}).get(log_id)
        if entry:
            log_path = entry.get("log")
            break
    if not log_path:
        return err("log not found", status=404)
    try:
        open(log_path, "w").close()
    except Exception as e:
        return err(str(e), status=500)
    return ok({"offset": 0})


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------

@app.route("/api/deps")
def api_check_deps():
    return call_helper("check_deps", {})


@app.route("/api/deps/install", methods=["POST"])
def api_install_deps():
    body = request.get_json(force=True)
    return call_helper("install_deps", body)


def main():
    app.run(host="127.0.0.1", port=8765, debug=False)


if __name__ == "__main__":
    main()
