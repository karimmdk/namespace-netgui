#!/usr/bin/env python3
"""
Standalone launcher for NetGUI Web -- run with `python3 run_web.py`.

Starts a local Flask server on 127.0.0.1:8765 and opens it in your default
browser. Privileged actions still go through pkexec exactly like the
desktop app (see netgui/core/bridge_client.py) -- this process itself does
not need root and should NOT be run with sudo/pkexec.
"""
import sys
import os
import threading
import webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from netgui.web.app import app

URL = "http://127.0.0.1:8765"


def _open_browser():
    webbrowser.open(URL)


if __name__ == "__main__":
    if os.geteuid() == 0:
        print("Do not run this as root/sudo/pkexec -- run it as your normal "
              "user. Privileged actions are still delegated to helper.py via "
              "pkexec on demand, same as the desktop app.")
        sys.exit(1)
    threading.Timer(1.0, _open_browser).start()
    print(f"NetGUI Web running at {URL}  (Ctrl+C to stop)")
    app.run(host="127.0.0.1", port=8765, debug=False)
