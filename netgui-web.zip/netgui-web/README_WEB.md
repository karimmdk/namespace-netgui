# NetGUI Web

A browser-based frontend for NetGUI, alongside (not instead of) the PyQt6 desktop app.
Same privileged backend, same `pkexec` model — just a nicer, tab-based UI you open at
`http://127.0.0.1:8765` instead of a Qt window.

## Run it

```bash
pip install -r requirements.txt --break-system-packages   # or use a venv
python3 run_web.py
```

This starts a local Flask server on `127.0.0.1:8765` (not exposed to your network) and
opens it in your default browser. **Do not run this with `sudo`/`pkexec`** — run it as
your normal user, exactly like `run.py`. Privileged actions (creating namespaces,
starting tunnels, etc.) still trigger a normal graphical `pkexec` password prompt the
first time each session, same as the desktop app.

Because `netgui/core/` is untouched apart from the fix below, saved profiles
(`~/.config/netgui/profiles.json`) are shared between the desktop app and this web
version automatically.

## What's different from the desktop app

- **Frontend**: a single HTML/CSS/JS page instead of PyQt6 widgets — a dark "signal
  routing console" theme with a live animated Host → hop → hop → App route bar that's
  visible from every tab, not just the Chain Wizard.
- **Backend**: `netgui/web/app.py`, a small Flask REST API that calls the exact same
  `netgui/core/bridge_client.call()` → `pkexec python3 helper.py` pipeline the desktop
  app uses. No new privileged code paths were introduced.
- **One bug fix in `helper.py`** (applies to both apps): the built-in SOCKS5 server's
  handshake parser used bare `conn.recv(n)` calls, which are not guaranteed to return
  all `n` bytes in a single call. That's usually invisible on a direct local socket, but
  once traffic is relayed through the extra `socat` / `ip netns exec` hops that the
  Bridges tab adds, reads can arrive fragmented and silently break the handshake — which
  shows up as "real apps like Telegram just won't connect" while `curl` tests run
  directly inside the namespace (bypassing the proxy entirely) keep working. Fixed with
  a `recv_exact()` loop. See the diff in your existing `netgui/core/helper.py` if you
  want to apply it there too instead of switching to this project wholesale.

## Project layout

```
netgui-web/
├── run_web.py                 # launcher (like run.py, but opens a browser instead)
├── requirements.txt
└── netgui/
    ├── core/                  # unchanged from the desktop app, + the SOCKS5 fix
    │   ├── bridge_client.py
    │   ├── constants.py
    │   ├── helper.py
    │   ├── presets.py
    │   └── profiles.py
    └── web/
        ├── app.py             # Flask REST API
        ├── templates/index.html
        └── static/{style.css, app.js}
```
